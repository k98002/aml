"""Wrapper to integrate TransactionGraphEnv with existing GCPN training code."""

from .transaction_env import TransactionGraphEnv


class TransactionEnvWrapper:
    """Compatibility wrapper around the attributed transaction environment."""

    def __init__(self, config):
        self.config = config
        self.env = TransactionGraphEnv(config)
        self.observation_space = self.env.observation_space
        self.action_space = self.env.action_space
        # Reserved NEW_NODE token remains at max_nodes - 1.
        self.atom_type_num = 1

    def reset(self):
        return self.env.reset()

    def step(self, action):
        """Take one attributed action.

        Expected action shape is `(7,)`, `(1, 7)`, or equivalent batch-1 form:
        [op, src, dst, amount_bin, delta_t_bin, currency, payment_type]
        """
        import numpy as np

        action = np.asarray(action)
        if action.ndim == 2:
            action = action.squeeze(0)
        return self.env.step(action)

    def seed(self, seed):
        self.env.seed(seed)

    def get_expert(self, batch_size, is_final=False, curriculum=0, level_total=6, level=0):
        return self.env.get_expert(
            batch_size=batch_size,
            is_final=is_final,
            curriculum=curriculum,
            level_total=level_total,
            level=level,
        )

    def close(self):
        pass
