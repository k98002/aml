"""
Attributed Transaction Graph Environment for AML Pattern Generation.

This environment is the Phase 1.5 bridge between the Issue 1 data pipeline
(unique, attributed transaction patterns) and the Issue 2 reward fix
(behavioural topology prior + weak realism regularizer).

Key changes versus the topology-only environment:
- State stores transaction events, not only a DiGraph edge weight.
- Observation exposes attributed edge channels and richer node features.
- Action is an all-discrete attributed transaction action:
    [op, src, dst, amount_bin, delta_t_bin, currency_id, payment_type_id]
  where op=0 means ADD_TX and op=1 means STOP.
- NEW_NODE can be selected on either endpoint, which removes the old fan-out bias.
- Expert imitation consumes `transactions` / `edge_events` produced by the fixed
  data pipeline, while keeping a fallback for old `edge_index` patterns.
"""

from __future__ import annotations

import json
import math
import random
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import networkx as nx
import numpy as np


# Action layout. Keep these integer constants stable because storage and PPO use
# the raw action tensor.
ACTION_OP = 0
ACTION_SRC = 1
ACTION_DST = 2
ACTION_AMOUNT_BIN = 3
ACTION_DELTA_T_BIN = 4
ACTION_CURRENCY = 5
ACTION_PAYMENT_TYPE = 6
ACTION_DIM = 7

OP_ADD_TX = 0
OP_STOP = 1


class TransactionGraphEnv:
    """Environment for attributed AML transaction-graph generation."""

    def __init__(self, config):
        self.config = config

        self.dataset_path = Path(config.dataset_path)
        self.offsets_path = Path(config.offsets_path)
        self.metadata_path = Path(getattr(config, "metadata_path", "")) if getattr(config, "metadata_path", None) else None

        self._load_metadata()
        self._load_dataset()
        self._load_stats()

        self.max_nodes = int(config.max_nodes)
        self.min_nodes = int(config.min_nodes)
        self.max_action = int(config.max_action)
        self.min_action = int(config.min_action)
        self.new_node_idx = self.max_nodes - 1

        self.base_edge_channels = int(getattr(config, "base_edge_channels", 5))
        include_cat = bool(getattr(config, "obs_include_categorical_edge_channels", True))
        self.edge_type_num = self.base_edge_channels + (self.currency_num + self.payment_type_num if include_cat else 0)
        self.node_feature_dim = int(getattr(config, "node_feature_dim", 15))

        self.current_graph: nx.DiGraph = nx.DiGraph()
        self.transactions: List[Dict[str, Any]] = []
        self.step_count = 0
        self.logical_time = 0.0
        self.last_reward_components: Dict[str, float] = {}

        self.observation_space = {
            "adj": np.zeros((self.edge_type_num, self.max_nodes, self.max_nodes), dtype=np.float32),
            "node": np.zeros((1, self.max_nodes, self.node_feature_dim), dtype=np.float32),
        }
        self.action_space = {
            "shape": (ACTION_DIM,),
            "n": [
                2,
                self.max_nodes,
                self.max_nodes,
                self.amount_bin_num,
                self.delta_t_bin_num,
                self.currency_num,
                self.payment_type_num,
            ],
            "schema": "attributed_discrete",
            "layout": ["op", "src", "dst", "amount_bin", "delta_t_bin", "currency", "payment_type"],
        }

    # ------------------------------------------------------------------
    # Loading helpers
    # ------------------------------------------------------------------
    def _load_metadata(self) -> None:
        """Load train-fitted bins/vocabularies from the Issue 1 pipeline.

        Missing metadata is not fatal; the config values are used as fallbacks so
        the code can still run on old topology-only pattern files.
        """
        self.metadata: Dict[str, Any] = {}
        if self.metadata_path and self.metadata_path.exists():
            with open(self.metadata_path, "r") as f:
                self.metadata = json.load(f)
            print(f"Loaded attributed metadata from {self.metadata_path}")
        elif self.metadata_path:
            print(f"Metadata file not found at {self.metadata_path}; using config fallbacks")

        self.amount_bin_num = int(
            self.metadata.get("amount_bin_num", getattr(self.config, "amount_bin_num", 16))
        )
        self.delta_t_bin_num = int(
            self.metadata.get("delta_t_bin_num", getattr(self.config, "delta_t_bin_num", 8))
        )

        currency_vocab = self.metadata.get("currency_vocab") or self.metadata.get("currencies")
        payment_vocab = (
            self.metadata.get("payment_type_vocab")
            or self.metadata.get("txn_type_vocab")
            or self.metadata.get("payment_types")
        )

        self.currency_to_id = self._normalise_vocab(currency_vocab)
        self.payment_type_to_id = self._normalise_vocab(payment_vocab)

        self.currency_num = max(
            len(self.currency_to_id), int(getattr(self.config, "currency_num", 1))
        )
        self.payment_type_num = max(
            len(self.payment_type_to_id), int(getattr(self.config, "payment_type_num", 1))
        )
        if not self.currency_to_id:
            self.currency_to_id = {"UNK": 0}
        if not self.payment_type_to_id:
            self.payment_type_to_id = {"UNK": 0}

        self.amount_bin_centers = self._load_bin_centers(
            keys=("amount_bin_centers", "amount_centers", "amount_bins"),
            num_bins=self.amount_bin_num,
            fallback_offset=1.0,
        )
        self.delta_t_bin_centers = self._load_bin_centers(
            keys=("delta_t_bin_centers", "delta_t_centers", "delta_t_bins", "time_bins"),
            num_bins=self.delta_t_bin_num,
            fallback_offset=1.0,
        )

    @staticmethod
    def _normalise_vocab(vocab: Any) -> Dict[str, int]:
        if vocab is None:
            return {}
        if isinstance(vocab, dict):
            out = {}
            for key, value in vocab.items():
                try:
                    out[str(key)] = int(value)
                except Exception:
                    pass
            return out
        if isinstance(vocab, list):
            return {str(v): i for i, v in enumerate(vocab)}
        return {}

    def _load_bin_centers(self, keys: Sequence[str], num_bins: int, fallback_offset: float) -> List[float]:
        values = None
        for key in keys:
            if key in self.metadata:
                values = self.metadata[key]
                break
        if values is None:
            return [float(i) + fallback_offset for i in range(num_bins)]

        try:
            vals = [float(v) for v in values]
        except Exception:
            return [float(i) + fallback_offset for i in range(num_bins)]

        # If bin edges were provided, convert to centers.
        if len(vals) == num_bins + 1:
            return [(vals[i] + vals[i + 1]) / 2.0 for i in range(num_bins)]
        if len(vals) >= num_bins:
            return vals[:num_bins]
        vals = vals + [vals[-1] if vals else fallback_offset] * (num_bins - len(vals))
        return vals[:num_bins]

    def _load_dataset(self) -> None:
        import pandas as pd

        index_path = Path(self.config.index_path)
        self.dataset_index = pd.read_csv(index_path)

        if getattr(self.config, "use_laundering_only", False):
            if "is_laundering" in self.dataset_index.columns:
                self.dataset_index = self.dataset_index[self.dataset_index["is_laundering"] == 1].reset_index(drop=True)
            else:
                print("Warning: use_laundering_only=True but is_laundering column is missing")

        # Optional Phase 1 representability filter.
        allowed_types = getattr(self.config, "representable_typologies", None)
        if allowed_types and "laundering_type" in self.dataset_index.columns:
            allowed = set(str(x) for x in allowed_types)
            before = len(self.dataset_index)
            self.dataset_index = self.dataset_index[
                self.dataset_index["laundering_type"].astype(str).isin(allowed)
            ].reset_index(drop=True)
            print(f"Filtered representable typologies: {before} -> {len(self.dataset_index)} patterns")

        with open(self.offsets_path, "r") as f:
            self.offsets = json.load(f)

        self.dataset_len = len(self.dataset_index)
        print(f"Loaded {self.dataset_len} patterns for training")

        self.type_to_indices: Dict[str, List[int]] = {}
        self.laundering_types: List[str] = []
        if getattr(self.config, "laundering_sampling", "uniform") == "balanced_per_type":
            if "laundering_type" in self.dataset_index.columns:
                for typ in self.dataset_index["laundering_type"].astype(str).unique():
                    indices = self.dataset_index[self.dataset_index["laundering_type"].astype(str) == typ].index.tolist()
                    if indices:
                        self.type_to_indices[typ] = indices
                        self.laundering_types.append(typ)
                print(f"Built balanced sampling lookup for {len(self.type_to_indices)} laundering types")
            else:
                print("Warning: laundering_type column not found; falling back to uniform sampling")

    def _load_stats(self) -> None:
        stats_path = Path(self.config.stats_path)
        if stats_path.exists():
            with open(stats_path, "r") as f:
                self.stats = json.load(f)
            print(f"Loaded dataset statistics from {stats_path}")
        else:
            print(f"Warning: Stats file not found at {stats_path}")
            self.stats = {}
        print(f"Reward mode: {getattr(self.config, 'reward_type', 'phase1_topology_behavior')}")

    def load_pattern(self, idx: int) -> Dict[str, Any]:
        pattern_id = self.dataset_index.iloc[idx]["pattern_id"]
        offset = self.offsets[str(pattern_id)]
        with open(self.dataset_path, "r") as f:
            f.seek(offset)
            return json.loads(f.readline())

    # ------------------------------------------------------------------
    # Environment API
    # ------------------------------------------------------------------
    def reset(self):
        self.current_graph = nx.DiGraph()
        self.current_graph.add_node(0)
        self.transactions = []
        self.step_count = 0
        self.logical_time = 0.0
        self.last_reward_components = {}
        return self._get_observation()

    def step(self, action):
        action = np.asarray(action).reshape(-1)
        if action.shape[0] != ACTION_DIM:
            raise ValueError(f"Expected attributed action of length {ACTION_DIM}, got {action.shape}")
        action = action.astype(np.int64)

        op = int(action[ACTION_OP])
        self.step_count += 1
        reward = 0.0
        done = False
        info: Dict[str, Any] = {}

        if op == OP_STOP:
            if self.step_count >= self.min_action:
                done = True
                reward = self._compute_terminal_reward(terminal_reason="stop")
                info.update(self._final_info("stop", timed_out=False))
                return self._get_observation(), reward, done, info
            reward = getattr(self.config, "invalid_action_penalty", -0.02)
            return self._get_observation(), reward, done, info

        if self.step_count >= self.max_action:
            done = True
            reward = self._compute_terminal_reward(terminal_reason="timeout")
            info.update(self._final_info("timeout", timed_out=True))
            return self._get_observation(), reward, done, info

        if op != OP_ADD_TX:
            reward = getattr(self.config, "invalid_action_penalty", -0.02)
            return self._get_observation(), reward, done, info

        src_raw = int(action[ACTION_SRC])
        dst_raw = int(action[ACTION_DST])
        amount_bin = int(action[ACTION_AMOUNT_BIN])
        delta_t_bin = int(action[ACTION_DELTA_T_BIN])
        currency_id = int(action[ACTION_CURRENCY])
        payment_type_id = int(action[ACTION_PAYMENT_TYPE])

        if not (0 <= amount_bin < self.amount_bin_num and 0 <= delta_t_bin < self.delta_t_bin_num):
            return self._invalid_step()
        if not (0 <= currency_id < self.currency_num and 0 <= payment_type_id < self.payment_type_num):
            return self._invalid_step()

        resolved = self._resolve_endpoints(src_raw, dst_raw)
        if resolved is None:
            return self._invalid_step()
        src, dst = resolved
        if src == dst:
            return self._invalid_step()

        amount_value = self._amount_from_bin(amount_bin)
        delta_t_value = self._delta_t_from_bin(delta_t_bin)
        self.logical_time += max(delta_t_value, 0.0)

        tx = {
            "src": int(src),
            "dst": int(dst),
            "amount": float(amount_value),
            "amount_bin": int(amount_bin),
            "delta_t": float(delta_t_value),
            "delta_t_bin": int(delta_t_bin),
            "timestamp": float(self.logical_time),
            "currency_id": int(currency_id),
            "payment_type_id": int(payment_type_id),
        }
        self._append_transaction(tx)
        reward = getattr(self.config, "step_new_edge_reward", 0.0)
        return self._get_observation(), reward, done, info

    def _invalid_step(self):
        reward = getattr(self.config, "invalid_action_penalty", -0.02)
        return self._get_observation(), reward, False, {}

    def _resolve_endpoints(self, src_raw: int, dst_raw: int) -> Optional[Tuple[int, int]]:
        n_nodes = self.current_graph.number_of_nodes()
        src_new = src_raw == self.new_node_idx
        dst_new = dst_raw == self.new_node_idx

        if src_new and dst_new:
            return None
        if src_new or dst_new:
            if n_nodes >= self.max_nodes - 1:
                return None
            new_idx = n_nodes
            self.current_graph.add_node(new_idx)
            if src_new:
                src = new_idx
                dst = dst_raw if 0 <= dst_raw < n_nodes else None
            else:
                src = src_raw if 0 <= src_raw < n_nodes else None
                dst = new_idx
            if src is None or dst is None:
                # Roll back the isolated new node.
                if self.current_graph.has_node(new_idx):
                    self.current_graph.remove_node(new_idx)
                return None
            return int(src), int(dst)

        if not (0 <= src_raw < n_nodes and 0 <= dst_raw < n_nodes):
            return None
        return int(src_raw), int(dst_raw)

    def _append_transaction(self, tx: Dict[str, Any], graph: Optional[nx.DiGraph] = None, transactions: Optional[List[Dict[str, Any]]] = None) -> None:
        g = graph if graph is not None else self.current_graph
        txs = transactions if transactions is not None else self.transactions
        src = int(tx["src"])
        dst = int(tx["dst"])
        g.add_node(src)
        g.add_node(dst)

        amount = float(tx.get("amount", self._amount_from_bin(int(tx.get("amount_bin", 0)))))
        currency_id = int(tx.get("currency_id", 0))
        payment_type_id = int(tx.get("payment_type_id", 0))
        timestamp = float(tx.get("timestamp", len(txs)))

        if g.has_edge(src, dst):
            data = g[src][dst]
            data["weight"] = data.get("weight", 0.0) + 1.0
            data["tx_count"] = data.get("tx_count", 0.0) + 1.0
            data["amount_sum"] = data.get("amount_sum", 0.0) + amount
            data["last_time"] = max(float(data.get("last_time", timestamp)), timestamp)
            data.setdefault("currency_counts", [0.0] * self.currency_num)
            data.setdefault("payment_type_counts", [0.0] * self.payment_type_num)
        else:
            g.add_edge(
                src,
                dst,
                weight=1.0,
                tx_count=1.0,
                amount_sum=amount,
                last_time=timestamp,
                currency_counts=[0.0] * self.currency_num,
                payment_type_counts=[0.0] * self.payment_type_num,
            )
            data = g[src][dst]

        if 0 <= currency_id < self.currency_num:
            data["currency_counts"][currency_id] += 1.0
        if 0 <= payment_type_id < self.payment_type_num:
            data["payment_type_counts"][payment_type_id] += 1.0
        data["amount_mean"] = float(data.get("amount_sum", 0.0)) / max(float(data.get("tx_count", 1.0)), 1.0)
        txs.append(dict(tx))

    # ------------------------------------------------------------------
    # Observation construction
    # ------------------------------------------------------------------
    def _get_observation(self):
        return self._observation_from_state(self.current_graph, self.transactions, self.logical_time)

    def _observation_from_state(self, g: nx.DiGraph, transactions: Sequence[Dict[str, Any]], logical_time: float):
        obs = {
            "adj": np.zeros((self.edge_type_num, self.max_nodes, self.max_nodes), dtype=np.float32),
            "node": np.zeros((1, self.max_nodes, self.node_feature_dim), dtype=np.float32),
        }
        nodes = sorted(int(n) for n in g.nodes() if int(n) < self.max_nodes - 1)
        node_to_pos = {node: i for i, node in enumerate(nodes[: self.max_nodes - 1])}

        for u, v, data in g.edges(data=True):
            if u not in node_to_pos or v not in node_to_pos:
                continue
            i = node_to_pos[int(u)]
            j = node_to_pos[int(v)]
            tx_count = float(data.get("tx_count", data.get("weight", 1.0)))
            amount_sum = float(data.get("amount_sum", tx_count))
            amount_mean = float(data.get("amount_mean", amount_sum / max(tx_count, 1.0)))
            last_time = float(data.get("last_time", logical_time))
            recentness = 1.0 / (1.0 + max(logical_time - last_time, 0.0))

            obs["adj"][0, i, j] = 1.0
            if self.edge_type_num > 1:
                obs["adj"][1, i, j] = min(math.log1p(tx_count) / 5.0, 1.0)
            if self.edge_type_num > 2:
                obs["adj"][2, i, j] = min(math.log1p(max(amount_sum, 0.0)) / 10.0, 1.0)
            if self.edge_type_num > 3:
                obs["adj"][3, i, j] = min(math.log1p(max(amount_mean, 0.0)) / 10.0, 1.0)
            if self.edge_type_num > 4:
                obs["adj"][4, i, j] = min(recentness, 1.0)

            ch = self.base_edge_channels
            if self.edge_type_num > ch:
                currency_counts = data.get("currency_counts", [0.0] * self.currency_num)
                denom = max(sum(currency_counts), 1.0)
                for k in range(min(self.currency_num, self.edge_type_num - ch)):
                    obs["adj"][ch + k, i, j] = float(currency_counts[k]) / denom
                ch += self.currency_num
            if self.edge_type_num > ch:
                payment_counts = data.get("payment_type_counts", [0.0] * self.payment_type_num)
                denom = max(sum(payment_counts), 1.0)
                for k in range(min(self.payment_type_num, self.edge_type_num - ch)):
                    obs["adj"][ch + k, i, j] = float(payment_counts[k]) / denom

        node_amount_in = {node: 0.0 for node in nodes}
        node_amount_out = {node: 0.0 for node in nodes}
        node_tx_in = {node: 0.0 for node in nodes}
        node_tx_out = {node: 0.0 for node in nodes}
        node_last = {node: 0.0 for node in nodes}
        node_first = {node: None for node in nodes}

        for tx in transactions:
            src = int(tx.get("src", -1))
            dst = int(tx.get("dst", -1))
            amount = float(tx.get("amount", self._amount_from_bin(int(tx.get("amount_bin", 0)))))
            t = float(tx.get("timestamp", logical_time))
            if src in node_to_pos:
                node_amount_out[src] += amount
                node_tx_out[src] += 1.0
                node_last[src] = max(node_last[src], t)
                node_first[src] = t if node_first[src] is None else min(node_first[src], t)
            if dst in node_to_pos:
                node_amount_in[dst] += amount
                node_tx_in[dst] += 1.0
                node_last[dst] = max(node_last[dst], t)
                node_first[dst] = t if node_first[dst] is None else min(node_first[dst], t)

        for node, idx in node_to_pos.items():
            in_deg = g.in_degree(node)
            out_deg = g.out_degree(node)
            in_amt = node_amount_in.get(node, 0.0)
            out_amt = node_amount_out.get(node, 0.0)
            in_tx = node_tx_in.get(node, 0.0)
            out_tx = node_tx_out.get(node, 0.0)
            first_t = node_first.get(node)
            last_t = node_last.get(node, 0.0)
            span = 0.0 if first_t is None else max(last_t - float(first_t), 0.0)
            recency = 0.0 if last_t <= 0 else 1.0 / (1.0 + max(logical_time - last_t, 0.0))
            balance_ratio = min(out_amt / (in_amt + 1.0), 2.0) / 2.0
            pass_ratio = min(min(in_amt, out_amt) / (max(in_amt, out_amt) + 1e-6), 1.0) if max(in_amt, out_amt) > 0 else 0.0
            source_role = 1.0 if in_deg == 0 and out_deg > 0 else 0.0
            inter_role = 1.0 if in_deg > 0 and out_deg > 0 else 0.0
            sink_role = 1.0 if in_deg > 0 and out_deg == 0 else 0.0

            feats = [
                min(in_deg / 10.0, 1.0),
                min(out_deg / 10.0, 1.0),
                min(math.log1p(in_tx) / 5.0, 1.0),
                min(math.log1p(out_tx) / 5.0, 1.0),
                min(math.log1p(in_amt) / 10.0, 1.0),
                min(math.log1p(out_amt) / 10.0, 1.0),
                balance_ratio,
                pass_ratio,
                min(math.log1p(span) / 10.0, 1.0),
                min(recency, 1.0),
                source_role,
                inter_role,
                sink_role,
                1.0,  # real-node marker
                0.0,  # NEW_NODE marker
            ]
            self._write_node_features(obs, idx, feats)

        # NEW_NODE token. The policy can select this as either src or dst.
        new_feats = [0.0] * max(self.node_feature_dim, 15)
        new_feats[14] = 1.0
        self._write_node_features(obs, self.new_node_idx, new_feats)
        return obs

    def _write_node_features(self, obs: Dict[str, np.ndarray], idx: int, feats: Sequence[float]) -> None:
        arr = np.zeros(self.node_feature_dim, dtype=np.float32)
        arr[: min(len(feats), self.node_feature_dim)] = np.asarray(feats[: self.node_feature_dim], dtype=np.float32)
        obs["node"][0, idx, :] = arr

    def _amount_from_bin(self, amount_bin: int) -> float:
        amount_bin = int(np.clip(amount_bin, 0, self.amount_bin_num - 1))
        return float(self.amount_bin_centers[amount_bin])

    def _delta_t_from_bin(self, delta_t_bin: int) -> float:
        delta_t_bin = int(np.clip(delta_t_bin, 0, self.delta_t_bin_num - 1))
        return float(self.delta_t_bin_centers[delta_t_bin])

    # ------------------------------------------------------------------
    # Pattern/event parsing for expert imitation
    # ------------------------------------------------------------------
    def _sample_dataset_index(self, curriculum: int, level_total: int, level: int) -> int:
        if getattr(self.config, "laundering_sampling", "uniform") == "balanced_per_type" and self.laundering_types:
            typ = np.random.choice(self.laundering_types)
            type_indices = self.type_to_indices[typ]
            if curriculum == 1:
                lo, hi = self._curriculum_bounds(len(type_indices), level_total, level)
                return type_indices[np.random.randint(lo, hi)]
            return int(np.random.choice(type_indices))
        if curriculum == 1:
            lo, hi = self._curriculum_bounds(self.dataset_len, level_total, level)
            return int(np.random.randint(lo, hi))
        return int(np.random.randint(0, self.dataset_len))

    @staticmethod
    def _curriculum_bounds(length: int, level_total: int, level: int) -> Tuple[int, int]:
        length = max(int(length), 1)
        lo = int((level / float(level_total)) * length)
        hi = int(((level + 1) / float(level_total)) * length)
        hi = min(max(hi, lo + 1), length)
        return lo, hi

    def _events_from_pattern(self, pattern: Dict[str, Any]) -> List[Dict[str, Any]]:
        raw_events = pattern.get("transactions") or pattern.get("edge_events") or pattern.get("events")
        if raw_events:
            events = [self._normalise_event(ev) for ev in raw_events]
            events = [ev for ev in events if ev is not None]
            events.sort(key=lambda ev: (float(ev.get("timestamp", 0.0)), int(ev.get("order", 0))))
            # Derive delta_t bins if not present.
            prev_t = None
            for ev in events:
                t = float(ev.get("timestamp", 0.0))
                if "delta_t_bin" not in ev:
                    ev["delta_t_bin"] = 0 if prev_t is None else self._value_to_ordinal_bin(max(t - prev_t, 0.0), self.delta_t_bin_num)
                prev_t = t
            return events

        # Fallback for the old topology-only `edge_index` format.
        edge_index = pattern.get("edge_index", [])
        edge_weights = pattern.get("edge_weight") or pattern.get("edge_weights") or [1] * len(edge_index)
        events: List[Dict[str, Any]] = []
        for order, edge in enumerate(edge_index):
            if len(edge) < 2:
                continue
            try:
                repeat = int(edge_weights[order]) if order < len(edge_weights) else 1
            except Exception:
                repeat = 1
            repeat = max(repeat, 1)
            for r in range(repeat):
                events.append(
                    {
                        "src_raw": edge[0],
                        "dst_raw": edge[1],
                        "amount": self._amount_from_bin(0),
                        "amount_bin": 0,
                        "delta_t": 1.0,
                        "delta_t_bin": 0,
                        "timestamp": float(len(events)),
                        "currency_id": 0,
                        "payment_type_id": 0,
                        "order": len(events),
                    }
                )
        return events

    def _normalise_event(self, ev: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        src = self._first_present(ev, ["src", "source", "sender", "from", "from_id", "u"])
        dst = self._first_present(ev, ["dst", "target", "receiver", "to", "to_id", "v"])
        if src is None or dst is None:
            return None

        amount_bin = self._first_present(ev, ["amount_bin", "amount_bucket", "amt_bin"])
        amount = self._first_present(ev, ["amount", "Amount", "amt", "value"])
        if amount_bin is None:
            amount_bin = self._value_to_ordinal_bin(float(amount or 0.0), self.amount_bin_num)
        amount_bin = int(np.clip(int(amount_bin), 0, self.amount_bin_num - 1))
        if amount is None:
            amount = self._amount_from_bin(amount_bin)

        delta_t_bin = self._first_present(ev, ["delta_t_bin", "time_bin", "dt_bin"])
        delta_t = self._first_present(ev, ["delta_t", "time_delta", "dt"])
        timestamp = self._first_present(ev, ["timestamp", "ts", "time", "datetime"])
        timestamp_float = self._timestamp_to_float(timestamp)
        if delta_t_bin is None:
            delta_t_bin = self._value_to_ordinal_bin(float(delta_t or 0.0), self.delta_t_bin_num)
        delta_t_bin = int(np.clip(int(delta_t_bin), 0, self.delta_t_bin_num - 1))
        if delta_t is None:
            delta_t = self._delta_t_from_bin(delta_t_bin)

        currency_id = self._first_present(ev, ["currency_id", "currency_idx"])
        currency = self._first_present(ev, ["currency", "Currency"])
        if currency_id is None:
            currency_id = self.currency_to_id.get(str(currency), 0)
        currency_id = int(np.clip(int(currency_id), 0, self.currency_num - 1))

        payment_type_id = self._first_present(ev, ["payment_type_id", "txn_type_id", "channel_id"])
        payment_type = self._first_present(ev, ["payment_type", "txn_type", "transaction_type", "type", "channel"])
        if payment_type_id is None:
            payment_type_id = self.payment_type_to_id.get(str(payment_type), 0)
        payment_type_id = int(np.clip(int(payment_type_id), 0, self.payment_type_num - 1))

        return {
            "src_raw": src,
            "dst_raw": dst,
            "amount": float(amount),
            "amount_bin": amount_bin,
            "delta_t": float(delta_t),
            "delta_t_bin": delta_t_bin,
            "timestamp": timestamp_float,
            "currency_id": currency_id,
            "payment_type_id": payment_type_id,
            "order": int(ev.get("order", 0)),
        }

    @staticmethod
    def _first_present(d: Dict[str, Any], keys: Sequence[str]) -> Any:
        for key in keys:
            if key in d and d[key] is not None:
                return d[key]
        return None

    @staticmethod
    def _timestamp_to_float(value: Any) -> float:
        if value is None:
            return 0.0
        if isinstance(value, (int, float, np.integer, np.floating)):
            return float(value)
        try:
            import pandas as pd

            ts = pd.to_datetime(value)
            return float(ts.timestamp())
        except Exception:
            try:
                return float(value)
            except Exception:
                return 0.0

    @staticmethod
    def _value_to_ordinal_bin(value: float, num_bins: int) -> int:
        # Fallback only. The fixed data pipeline should provide train-fitted bins.
        if num_bins <= 1:
            return 0
        if value <= 0:
            return 0
        return int(np.clip(math.log1p(value), 0, num_bins - 1))

    def _expert_prefix_to_obs_and_action(self, events: List[Dict[str, Any]], is_final: bool = False):
        if not events:
            g_empty = nx.DiGraph()
            g_empty.add_node(0)
            obs = self._observation_from_state(g_empty, [], 0.0)
            return obs, np.array([OP_STOP, 0, 0, 0, 0, 0, 0], dtype=np.int64)

        # Seed the local construction with the first event's source, matching reset().
        raw_to_local: Dict[Any, int] = {events[0]["src_raw"]: 0}
        local_next = 1

        show_stop = random.random() < float(getattr(self.config, "expert_stop_prob", 0.25))
        if is_final or show_stop:
            k = len(events)
        else:
            k = random.randint(0, max(len(events) - 1, 0))

        g = nx.DiGraph()
        g.add_node(0)
        txs: List[Dict[str, Any]] = []
        logical_time = 0.0

        def map_raw(raw: Any) -> int:
            nonlocal local_next
            if raw not in raw_to_local:
                raw_to_local[raw] = local_next
                local_next += 1
            return raw_to_local[raw]

        for ev in events[:k]:
            src = map_raw(ev["src_raw"])
            dst = map_raw(ev["dst_raw"])
            if src >= self.max_nodes - 1 or dst >= self.max_nodes - 1:
                break
            logical_time += self._delta_t_from_bin(int(ev.get("delta_t_bin", 0)))
            tx = {
                "src": src,
                "dst": dst,
                "amount": float(ev.get("amount", self._amount_from_bin(int(ev.get("amount_bin", 0))))),
                "amount_bin": int(ev.get("amount_bin", 0)),
                "delta_t": float(ev.get("delta_t", self._delta_t_from_bin(int(ev.get("delta_t_bin", 0))))),
                "delta_t_bin": int(ev.get("delta_t_bin", 0)),
                "timestamp": logical_time,
                "currency_id": int(ev.get("currency_id", 0)),
                "payment_type_id": int(ev.get("payment_type_id", 0)),
            }
            self._append_transaction(tx, graph=g, transactions=txs)

        obs = self._observation_from_state(g, txs, logical_time)

        if k >= len(events):
            return obs, np.array([OP_STOP, 0, 0, 0, 0, 0, 0], dtype=np.int64)

        next_ev = events[k]
        src_known = next_ev["src_raw"] in raw_to_local
        dst_known = next_ev["dst_raw"] in raw_to_local
        if not src_known and not dst_known:
            # Disconnected next event. Use STOP rather than train an invalid action.
            return obs, np.array([OP_STOP, 0, 0, 0, 0, 0, 0], dtype=np.int64)

        src_action = raw_to_local[next_ev["src_raw"]] if src_known else self.new_node_idx
        dst_action = raw_to_local[next_ev["dst_raw"]] if dst_known else self.new_node_idx
        if (src_action != self.new_node_idx and src_action >= self.max_nodes - 1) or (
            dst_action != self.new_node_idx and dst_action >= self.max_nodes - 1
        ):
            return obs, np.array([OP_STOP, 0, 0, 0, 0, 0, 0], dtype=np.int64)

        action = np.array(
            [
                OP_ADD_TX,
                int(src_action),
                int(dst_action),
                int(next_ev.get("amount_bin", 0)),
                int(next_ev.get("delta_t_bin", 0)),
                int(next_ev.get("currency_id", 0)),
                int(next_ev.get("payment_type_id", 0)),
            ],
            dtype=np.int64,
        )
        return obs, action

    def get_expert(self, batch_size, is_final=False, curriculum=0, level_total=6, level=0):
        obs_batch = {
            "adj": np.zeros((batch_size, self.edge_type_num, self.max_nodes, self.max_nodes), dtype=np.float32),
            "node": np.zeros((batch_size, 1, self.max_nodes, self.node_feature_dim), dtype=np.float32),
        }
        actions_batch = np.zeros((batch_size, ACTION_DIM), dtype=np.int64)

        for i in range(batch_size):
            idx = self._sample_dataset_index(curriculum, level_total, level)
            pattern = self.load_pattern(idx)
            events = self._events_from_pattern(pattern)
            obs, action = self._expert_prefix_to_obs_and_action(events, is_final=is_final)
            obs_batch["adj"][i] = obs["adj"]
            obs_batch["node"][i] = obs["node"]
            actions_batch[i] = action

        return obs_batch, actions_batch

    # ------------------------------------------------------------------
    # Reward and metrics. Issue 2 reward stays topology-behaviour first; the
    # attributed observation/action interface now makes amount/time available for
    # later reward extensions without reverting to statistic matching.
    # ------------------------------------------------------------------
    def _final_info(self, reason: str, timed_out: bool) -> Dict[str, Any]:
        info = {
            "final_graph": self.current_graph.copy(),
            "transactions": list(self.transactions),
            "stop_reason": reason,
            "timed_out": timed_out,
        }
        info.update(self._compute_graph_metrics())
        info.update(getattr(self, "last_reward_components", {}))
        return info

    def _compute_terminal_reward(self, terminal_reason="stop"):
        reward_type = getattr(self.config, "reward_type", "phase1_topology_behavior")
        if reward_type == "phase1_topology_behavior":
            return self._phase1_topology_behavior_reward(terminal_reason=terminal_reason)
        if reward_type == "structural_smooth":
            reward = self._structural_reward_smooth()
            if terminal_reason == "timeout":
                reward -= getattr(self.config, "timeout_penalty", 0.25)
            self.last_reward_components = {"r_total": float(reward)}
            return float(reward)
        if reward_type == "structural":
            reward = self._structural_reward()
            if terminal_reason == "timeout":
                reward -= getattr(self.config, "timeout_penalty", 0.25)
            self.last_reward_components = {"r_total": float(reward)}
            return float(reward)
        self.last_reward_components = {"r_total": 0.0}
        return 0.0

    def _compute_graph_metrics(self):
        g = self.current_graph
        n = g.number_of_nodes()
        m = g.number_of_edges()
        weakly_connected = nx.is_weakly_connected(g) if n > 0 else False
        num_components = nx.number_weakly_connected_components(g) if n > 0 else 0
        cycles = self._limited_simple_cycle_count(g, max_cycles=100)
        try:
            depth = nx.diameter(g.to_undirected()) if weakly_connected and n > 1 else 0
        except Exception:
            depth = 0
        max_out = max(dict(g.out_degree()).values()) if n > 0 else 0
        total_tx = len(self.transactions)
        total_amount = sum(float(tx.get("amount", 0.0)) for tx in self.transactions)
        return {
            "weakly_connected": weakly_connected,
            "num_components": num_components,
            "cycles": cycles,
            "depth": depth,
            "max_out": max_out,
            "tx_count": total_tx,
            "total_amount": total_amount,
        }

    @staticmethod
    def _bounded_exp_score(value, mean, std, min_scale=1.0, broadness=4.0):
        scale = max(float(std) * float(broadness), float(min_scale))
        return float(np.exp(-abs(float(value) - float(mean)) / scale))

    def _get_global_targets(self):
        if isinstance(self.stats, dict) and "_global" in self.stats:
            return self.stats["_global"]
        return {
            "n": {"mean": 8.0, "std": 3.0},
            "m_unique": {"mean": 7.0, "std": 3.0},
            "depth": {"mean": 3.0, "std": 2.0},
        }

    @staticmethod
    def _directed_max_shortest_path(g):
        max_len = 0
        try:
            for _, lengths in nx.all_pairs_shortest_path_length(g):
                if lengths:
                    max_len = max(max_len, max(lengths.values()))
        except Exception:
            max_len = 0
        return int(max_len)

    @staticmethod
    def _limited_simple_cycle_count(g, max_cycles=100):
        """Count simple cycles with a hard cap to avoid exponential blow-ups."""
        count = 0
        try:
            for _ in nx.simple_cycles(g):
                count += 1
                if count >= max_cycles:
                    return count
        except Exception:
            return 0
        return count

    def _validity_score(self, g):
        n = g.number_of_nodes()
        m = g.number_of_edges()
        if n < self.min_nodes or m < 2:
            return 0.0
        weak = 1.0 if nx.is_weakly_connected(g) else 0.0
        isolates = len(list(nx.isolates(g)))
        no_isolates = 1.0 if isolates == 0 else max(0.0, 1.0 - isolates / max(n, 1))
        size_ok = 1.0 if n <= self.max_nodes - 1 and len(self.transactions) <= self.max_action else 0.0
        density = m / max(n * (n - 1), 1)
        max_density = getattr(self.config, "max_density_phase1", 0.35)
        density_ok = 1.0 if density <= max_density else max(0.0, 1.0 - (density - max_density) / max_density)
        return float(0.35 * weak + 0.25 * no_isolates + 0.25 * size_ok + 0.15 * density_ok)

    def _aml_topology_prior_score(self, g):
        n = g.number_of_nodes()
        m = g.number_of_edges()
        if n < self.min_nodes or m < 2:
            return 0.0
        in_deg = dict(g.in_degree())
        out_deg = dict(g.out_degree())
        max_in = max(in_deg.values(), default=0)
        max_out = max(out_deg.values(), default=0)
        pass_nodes = [v for v in g.nodes() if in_deg.get(v, 0) > 0 and out_deg.get(v, 0) > 0]
        pass_ratio = len(pass_nodes) / max(n, 1)
        max_path = self._directed_max_shortest_path(g)
        path_score = min(max(max_path - 1, 0) / 3.0, 1.0)
        pass_score = min(pass_ratio / 0.35, 1.0)
        layering = 0.60 * path_score + 0.40 * pass_score
        fan_in = min(max(max_in - 1, 0) / 3.0, 1.0)
        fan_out = min(max(max_out - 1, 0) / 3.0, 1.0)
        cycle_count = self._limited_simple_cycle_count(g, max_cycles=100)
        circular = min(cycle_count / 2.0, 1.0)
        sources = sum(1 for v in g.nodes() if in_deg.get(v, 0) == 0 and out_deg.get(v, 0) > 0)
        sinks = sum(1 for v in g.nodes() if in_deg.get(v, 0) > 0 and out_deg.get(v, 0) == 0)
        role_structure = 1.0 if sources > 0 and sinks > 0 and len(pass_nodes) > 0 else 0.0
        motif_scores = sorted([layering, fan_in, fan_out, circular, role_structure], reverse=True)
        return float(0.75 * motif_scores[0] + 0.25 * motif_scores[1])

    def _realism_regularizer_score(self, g):
        n = g.number_of_nodes()
        m = g.number_of_edges()
        depth = self._directed_max_shortest_path(g)
        targets = self._get_global_targets()
        n_score = self._bounded_exp_score(n, targets["n"]["mean"], targets["n"]["std"], min_scale=3.0, broadness=4.0)
        m_score = self._bounded_exp_score(m, targets["m_unique"]["mean"], targets["m_unique"]["std"], min_scale=3.0, broadness=4.0)
        d_tgt = targets.get("depth", {"mean": 3.0, "std": 2.0})
        d_score = self._bounded_exp_score(depth, d_tgt["mean"], d_tgt["std"], min_scale=2.0, broadness=4.0)
        density = m / max(n * (n - 1), 1)
        max_density = getattr(self.config, "max_density_phase1", 0.35)
        density_score = 1.0 if density <= max_density else max(0.0, 1.0 - (density - max_density) / max_density)
        return float(0.30 * n_score + 0.30 * m_score + 0.20 * d_score + 0.20 * density_score)

    def _anti_degenerate_score(self, g):
        n = g.number_of_nodes()
        m = g.number_of_edges()
        if n == 0:
            return 0.0
        total_tx = max(len(self.transactions), 1)
        unique_edge_ratio = m / total_tx
        max_in = max(dict(g.in_degree()).values(), default=0)
        max_out = max(dict(g.out_degree()).values(), default=0)
        hub_ratio = max(max_in, max_out) / max(n - 1, 1)
        allowed_hub_ratio = getattr(self.config, "allowed_hub_ratio_phase1", 0.80)
        hub_score = 1.0 if hub_ratio <= allowed_hub_ratio else max(0.0, 1.0 - (hub_ratio - allowed_hub_ratio) / max(1.0 - allowed_hub_ratio, 1e-6))
        density = m / max(n * (n - 1), 1)
        max_density = getattr(self.config, "max_density_phase1", 0.35)
        density_score = 1.0 if density <= max_density else max(0.0, 1.0 - (density - max_density) / max_density)
        return float(0.40 * unique_edge_ratio + 0.30 * hub_score + 0.30 * density_score)

    def _stop_quality_score(self, terminal_reason="stop"):
        if terminal_reason == "timeout":
            return 0.0
        n = self.current_graph.number_of_nodes()
        m = self.current_graph.number_of_edges()
        enough_graph = 1.0 if n >= self.min_nodes and m >= 2 else 0.0
        enough_steps = 1.0 if self.step_count >= self.min_action else 0.0
        return float(0.50 * enough_graph + 0.50 * enough_steps)

    def _phase1_topology_behavior_reward(self, terminal_reason="stop"):
        g = self.current_graph
        n = g.number_of_nodes()
        m = g.number_of_edges()
        if n < self.min_nodes or m < 2:
            reward = -1.0
            if terminal_reason == "timeout":
                reward -= getattr(self.config, "timeout_penalty", 0.25)
            self.last_reward_components = {
                "r_valid": 0.0,
                "r_aml": 0.0,
                "r_realism": 0.0,
                "r_anti_degenerate": 0.0,
                "r_stop_quality": 0.0,
                "r_total": float(reward),
            }
            return float(reward)

        r_valid = self._validity_score(g)
        r_aml = self._aml_topology_prior_score(g)
        r_realism = self._realism_regularizer_score(g)
        r_anti = self._anti_degenerate_score(g)
        r_stop = self._stop_quality_score(terminal_reason=terminal_reason)
        reward = (
            getattr(self.config, "reward_w_valid", 0.20) * r_valid
            + getattr(self.config, "reward_w_aml", 0.45) * r_aml
            + getattr(self.config, "reward_w_realism", 0.15) * r_realism
            + getattr(self.config, "reward_w_anti_degenerate", 0.10) * r_anti
            + getattr(self.config, "reward_w_stop_quality", 0.10) * r_stop
        )
        if terminal_reason == "timeout":
            reward -= getattr(self.config, "timeout_penalty", 0.25)
        self.last_reward_components = {
            "r_valid": float(r_valid),
            "r_aml": float(r_aml),
            "r_realism": float(r_realism),
            "r_anti_degenerate": float(r_anti),
            "r_stop_quality": float(r_stop),
            "r_total": float(reward),
        }
        return float(reward)

    def _structural_reward(self):
        n = self.current_graph.number_of_nodes()
        m = self.current_graph.number_of_edges()
        if n < self.min_nodes or m < 2:
            return -1.0
        reward = 1.0 if 5 <= n <= 20 else 0.5
        if nx.is_weakly_connected(self.current_graph):
            reward += 0.5
        return float(reward)

    def _structural_reward_smooth(self):
        # Kept only for backward compatibility. Phase 1.5 should use
        # phase1_topology_behavior.
        g = self.current_graph
        n = g.number_of_nodes()
        m = g.number_of_edges()
        if n < self.min_nodes or m < 2:
            return -1.0
        targets = self._get_global_targets()
        n_score = self._bounded_exp_score(n, targets["n"]["mean"], targets["n"]["std"])
        m_score = self._bounded_exp_score(m, targets["m_unique"]["mean"], targets["m_unique"]["std"])
        reward = 0.5 * n_score + 0.5 * m_score
        reward += getattr(self.config, "connected_bonus", 0.20) if nx.is_weakly_connected(g) else -getattr(self.config, "disconnect_penalty", 0.30)
        return float(reward)

    def seed(self, seed):
        random.seed(seed)
        np.random.seed(seed)
