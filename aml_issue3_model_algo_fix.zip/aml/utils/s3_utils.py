"""Local fallback for optional S3 dataset bootstrap.

The original project referenced this module but the zip did not include it. This
stub keeps local runs from failing at import time; remote deployments can replace
it with the real implementation.
"""


def ensure_dataset_files(data_dir: str, verbose: bool = True) -> bool:
    if verbose:
        print("s3_utils fallback: no S3 downloader configured")
    return False
