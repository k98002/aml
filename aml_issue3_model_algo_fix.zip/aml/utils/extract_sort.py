import json
import os
import re
from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple, Optional

import pandas as pd
import networkx as nx
from networkx.utils import UnionFind
from s3_utils import ensure_saml_d_csv

# =============================================================================
# CONFIG - FIXED VERSION
# =============================================================================

# Output directory (relative to script location)
OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

# Input CSV path - will be downloaded from S3 if not found
CSV_PATH = os.path.join(OUT_DIR, "SAML-D.csv")
SEP = ","

OUT_JSONL = os.path.join(OUT_DIR, "patterns.jsonl")
OUT_OFFSETS = os.path.join(OUT_DIR, "patterns_offsets.json")
OUT_INDEX_UNSORTED = os.path.join(OUT_DIR, "patterns_index_unsorted.csv")
OUT_INDEX_SORTED = os.path.join(OUT_DIR, "patterns_sorted.csv")
OUT_STATS = os.path.join(OUT_DIR, "dataset_stats.json")
OUT_STATS_BY_TYPE = os.path.join(OUT_DIR, "patterns_stats_by_type.json")

CHUNKSIZE = 200000

# Optional: keep only laundering edges / only normal / or all
FILTER_LAUNDERING: Optional[int] = None  # None / 0 / 1

# =============================================================================
# CRITICAL FIX
# =============================================================================

# OPTION 1: Disable session splitting entirely (RECOMMENDED)
USE_SESSION_SPLIT = False
SESSION_GAP = pd.Timedelta("2h")  # Not used when USE_SESSION_SPLIT=False

# =============================================================================

# Filter out trivial patterns
MIN_NODES = 3
MIN_TX = 2
MIN_UNIQUE_EDGES = 2

# If a bucket grows too large, we flush it
MAX_BUCKET_ROWS = 300000

# Class balancing: oversample laundering patterns
LAUNDERING_MULTIPLIER = 10  # Repeat laundering patterns N times

# Bucketing key: Group by (Date, Laundering_type) without time binning
TIME_BIN: Optional[str] = None

# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass(frozen=True)
class TxRow:
    tx_id: int
    ts: pd.Timestamp
    sender: str
    receiver: str
    is_laundering: int
    laundering_type: str
    date: str
    time_bin: Optional[pd.Timestamp]

# =============================================================================
# UTILS
# =============================================================================

def _safe_filename(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9_.-]+", "_", s)
    return s[:180]

def _cyclomatic_number_undirected(n: int, undirected_edge_count: int) -> int:
    return max(0, undirected_edge_count - n + 1)

def _depth_via_scc_condensation(dg: nx.DiGraph) -> int:
    if dg.number_of_nodes() <= 1 or dg.number_of_edges() == 0:
        return 0 if dg.number_of_edges() == 0 else 1
    C = nx.condensation(dg)
    return nx.dag_longest_path_length(C) if C.number_of_edges() > 0 else 0

def _compute_complexity(node_ids: List[str], edge_counts: Dict[Tuple[str, str], int]) -> Dict[str, int]:
    n = len(node_ids)
    m_unique = len(edge_counts)

    dg = nx.DiGraph()
    dg.add_nodes_from(node_ids)
    dg.add_edges_from(edge_counts.keys())

    max_out = max((d for _, d in dg.out_degree()), default=0)

    undirected_edges = {tuple(sorted((u, v))) for (u, v) in edge_counts.keys()}
    cycles = _cyclomatic_number_undirected(n=n, undirected_edge_count=len(undirected_edges))

    depth = _depth_via_scc_condensation(dg)

    return {
        "n": n,
        "m_unique": m_unique,
        "cycles": cycles,
        "depth": depth,
        "max_out": max_out,
    }

def _union_find_components(rows: List[TxRow]) -> List[List[TxRow]]:
    uf = UnionFind()
    for r in rows:
        uf.union(r.sender, r.receiver)

    groups: Dict[str, List[TxRow]] = defaultdict(list)
    for r in rows:
        root = uf[r.sender]
        groups[root].append(r)

    return list(groups.values())

def _session_split(rows: List[TxRow], gap: pd.Timedelta) -> List[List[TxRow]]:
    rows_sorted = sorted(rows, key=lambda r: r.ts)
    sessions: List[List[TxRow]] = []
    cur: List[TxRow] = []
    last_ts: Optional[pd.Timestamp] = None

    for r in rows_sorted:
        if last_ts is not None and (r.ts - last_ts) > gap and cur:
            sessions.append(cur)
            cur = []
        cur.append(r)
        last_ts = r.ts

    if cur:
        sessions.append(cur)
    return sessions

def _build_pattern_instance(rows: List[TxRow], pattern_id: str) -> Optional[dict]:
    if not rows:
        return None

    node_set = set()
    for r in rows:
        node_set.add(r.sender)
        node_set.add(r.receiver)

    node_ids = sorted(node_set)
    node_map = {nid: i for i, nid in enumerate(node_ids)}

    edge_counts: Dict[Tuple[str, str], int] = defaultdict(int)
    tx_ids = []
    for r in rows:
        edge_counts[(r.sender, r.receiver)] += 1
        tx_ids.append(r.tx_id)

    tx_ids = sorted(set(tx_ids))

    edge_index = []
    edge_weight = []
    for (u, v), c in edge_counts.items():
        edge_index.append([node_map[u], node_map[v]])
        edge_weight.append(c)

    laundering_type = rows[0].laundering_type
    is_laundering = int(any(r.is_laundering == 1 for r in rows))
    start_ts = min(r.ts for r in rows)
    end_ts = max(r.ts for r in rows)

    compx = _compute_complexity(node_ids=node_ids, edge_counts=edge_counts)

    if compx["n"] < MIN_NODES:
        return None
    if len(rows) < MIN_TX:
        return None
    if compx["m_unique"] < MIN_UNIQUE_EDGES:
        return None

    return {
        "pattern_id": pattern_id,
        "laundering_type": laundering_type,
        "is_laundering": is_laundering,
        "start_ts": str(start_ts),
        "end_ts": str(end_ts),
        "tx_ids": tx_ids,
        "node_ids": node_ids,
        "node_map": node_map,
        "edge_index": edge_index,
        "edge_weight": edge_weight,
        "complexity": compx,
    }

def _extract_patterns_from_bucket(bucket_rows: List[TxRow], pattern_counter: int, fout_jsonl, offsets: Dict[str, int], index_writer) -> int:
    if not bucket_rows:
        return pattern_counter

    comps = _union_find_components(bucket_rows)

    for comp_rows in comps:
        parts = _session_split(comp_rows, SESSION_GAP) if USE_SESSION_SPLIT else [comp_rows]

        for part_rows in parts:
            subcomps = _union_find_components(part_rows)

            for sub in subcomps:
                pattern_id = f"P{pattern_counter:07d}"
                rec = _build_pattern_instance(sub, pattern_id)
                pattern_counter += 1

                if rec is None:
                    continue

                offsets[rec["pattern_id"]] = fout_jsonl.tell()
                fout_jsonl.write(json.dumps(rec) + "\n")

                c = rec["complexity"]
                index_writer.write(
                    f'{rec["pattern_id"]},'
                    f'{rec["laundering_type"]},'
                    f'{rec["is_laundering"]},'
                    f'{c["n"]},{c["m_unique"]},{c["cycles"]},{c["depth"]},{c["max_out"]},'
                    f'{len(rec["tx_ids"])},'
                    f'{rec["start_ts"]},{rec["end_ts"]}\n'
                )

    return pattern_counter

# =============================================================================
# STATISTICS
# =============================================================================

def _extract_stats_by_type(index_path: str, output_path: str):
    df = pd.read_csv(index_path)

    df_launder = df[df['is_laundering'] == 1].copy()

    stats = {}

    for launder_type in sorted(df_launder['laundering_type'].unique()):
        type_df = df_launder[df_launder['laundering_type'] == launder_type]

        stats[launder_type] = {
            'count': int(type_df.shape[0]),
            'n': {
                'mean': float(type_df['n'].mean()),
                'std': float(type_df['n'].std()),
                'min': int(type_df['n'].min()),
                'max': int(type_df['n'].max()),
            },
            'm_unique': {
                'mean': float(type_df['m_unique'].mean()),
                'std': float(type_df['m_unique'].std()),
                'min': int(type_df['m_unique'].min()),
                'max': int(type_df['m_unique'].max()),
            },
            'cycles': {
                'mean': float(type_df['cycles'].mean()),
                'std': float(type_df['cycles'].std()),
                'min': int(type_df['cycles'].min()),
                'max': int(type_df['cycles'].max()),
            },
            'depth': {
                'mean': float(type_df['depth'].mean()),
                'std': float(type_df['depth'].std()),
                'min': int(type_df['depth'].min()),
                'max': int(type_df['depth'].max()),
            },
            'max_out': {
                'mean': float(type_df['max_out'].mean()),
                'std': float(type_df['max_out'].std()),
                'min': int(type_df['max_out'].min()),
                'max': int(type_df['max_out'].max()),
            },
        }

    # Also compute global stats for all laundering patterns
    stats['_global'] = {
        'count': int(df_launder.shape[0]),
        'n': {
            'mean': float(df_launder['n'].mean()),
            'std': float(df_launder['n'].std()),
            'min': int(df_launder['n'].min()),
            'max': int(df_launder['n'].max()),
        },
        'm_unique': {
            'mean': float(df_launder['m_unique'].mean()),
            'std': float(df_launder['m_unique'].std()),
            'min': int(df_launder['m_unique'].min()),
            'max': int(df_launder['m_unique'].max()),
        },
        'cycles': {
            'mean': float(df_launder['cycles'].mean()),
            'std': float(df_launder['cycles'].std()),
            'min': int(df_launder['cycles'].min()),
            'max': int(df_launder['cycles'].max()),
        },
        'depth': {
            'mean': float(df_launder['depth'].mean()),
            'std': float(df_launder['depth'].std()),
            'min': int(df_launder['depth'].min()),
            'max': int(df_launder['depth'].max()),
        },
        'max_out': {
            'mean': float(df_launder['max_out'].mean()),
            'std': float(df_launder['max_out'].std()),
            'min': int(df_launder['max_out'].min()),
            'max': int(df_launder['max_out'].max()),
        },
    }

    with open(output_path, 'w') as f:
        json.dump(stats, f, indent=2)

    return stats

# =============================================================================
# MAIN
# =============================================================================

def build_patterns():
    os.makedirs(OUT_DIR, exist_ok=True)

    if not os.path.exists(CSV_PATH):
        print("="*70)
        print("SAML-D.csv not found locally. Attempting to download from S3...")
        print("="*70)
        if not ensure_saml_d_csv(OUT_DIR, verbose=True):
            raise FileNotFoundError(
                f"SAML-D.csv not found at {CSV_PATH} and could not be downloaded from S3.\n"
                f"Place SAML-D.csv in {OUT_DIR}/ or ensure AWS S3 access is configured."
            )

    print(f"Using SAMl-D.csv from: {CSV_PATH}")

    buckets: Dict[Tuple, List[TxRow]] = defaultdict(list)
    bucket_sizes: Dict[Tuple, int] = defaultdict(int)
    offsets: Dict[str, int] = {}
    pattern_counter = 0
    offset_tx = 0

    with open(OUT_INDEX_UNSORTED, "w", encoding="utf-8") as fidx:
        fidx.write("pattern_id,laundering_type,is_laundering,n,m_unique,cycles,depth,max_out,tx_count,start_ts,end_ts\n")

    with open(OUT_JSONL, "w", encoding="utf-8") as fout:
        for chunk in pd.read_csv(
            CSV_PATH,
            sep=SEP,
            chunksize=CHUNKSIZE,
            dtype={"Sender_account": str, "Receiver_account": str, "Laundering_type": str},
        ):
            chunk["tx_id"] = range(offset_tx, offset_tx + len(chunk))
            offset_tx += len(chunk)

            if "ts" not in chunk.columns:
                chunk["ts"] = pd.to_datetime(chunk["Date"].astype(str) + " " + chunk["Time"].astype(str), errors="coerce")
            else:
                chunk["ts"] = pd.to_datetime(chunk["ts"], errors="coerce")

            chunk = chunk.dropna(subset=["ts", "Sender_account", "Receiver_account", "Laundering_type", "Date", "Is_laundering"])

            if FILTER_LAUNDERING is not None:
                chunk = chunk[chunk["Is_laundering"] == FILTER_LAUNDERING]
                if chunk.empty:
                    continue

            if TIME_BIN is not None:
                chunk["time_bin"] = chunk["ts"].dt.floor(TIME_BIN)
            else:
                chunk["time_bin"] = pd.NaT

            for r in chunk[["tx_id", "ts", "Sender_account", "Receiver_account", "Is_laundering", "Laundering_type", "Date", "time_bin"]].itertuples(index=False):
                row = TxRow(
                    tx_id=int(r.tx_id),
                    ts=r.ts,
                    sender=str(r.Sender_account),
                    receiver=str(r.Receiver_account),
                    is_laundering=int(r.Is_laundering),
                    laundering_type=str(r.Laundering_type),
                    date=str(r.Date),
                    time_bin=None if pd.isna(r.time_bin) else r.time_bin,
                )

                if TIME_BIN is None:
                    if row.is_laundering == 1:
                        key = (row.laundering_type,)
                    else:
                        key = (row.date, row.laundering_type)
                else:
                    key = (row.date, row.laundering_type, row.time_bin)

                buckets[key].append(row)
                bucket_sizes[key] += 1

                if bucket_sizes[key] >= MAX_BUCKET_ROWS:
                    pattern_counter = _extract_patterns_from_bucket(
                        buckets[key], pattern_counter, fout, offsets, fidx
                    )
                    buckets[key].clear()
                    bucket_sizes[key] = 0

        # flush leftovers
        for key, rows in list(buckets.items()):
            if rows:
                pattern_counter = _extract_patterns_from_bucket(
                    rows, pattern_counter, fout, offsets, fidx
                )

    with open(OUT_OFFSETS, "w", encoding="utf-8") as foff:
        json.dump(offsets, foff)

    idx = pd.read_csv(OUT_INDEX_UNSORTED)

    print("="*70)
    print("DATASET STATISTICS (before balancing)")
    print("="*70)
    print(f"Total patterns: {len(idx):,}")
    print(f"Laundering patterns: {len(idx[idx['is_laundering']==1]):,}")
    print(f"Normal patterns: {len(idx[idx['is_laundering']==0]):,}")

    if LAUNDERING_MULTIPLIER > 1:
        print("="*70)
        print(f"BALANCING: Oversampling laundering {LAUNDERING_MULTIPLIER}x")
        print("="*70)

        laundering = idx[idx['is_laundering'] == 1]
        normal = idx[idx['is_laundering'] == 0]

        laundering_repeated = pd.concat([laundering] * LAUNDERING_MULTIPLIER, ignore_index=True)
        idx = pd.concat([normal, laundering_repeated], ignore_index=True)

        print(f"After balancing: {len(idx):,} patterns")
        print(f" Laundering: {len(laundering_repeated):,} ({len(laundering_repeated)/len(idx)*100:.1f}%)")
        print(f" Normal:     {len(normal):,} ({len(normal)/len(idx)*100:.1f}%)")

    print("="*70)
    print("SORTING BY COMPLEXITY (curriculum order)")
    print("="*70)
    idx = idx.sort_values(["n", "m_unique", "cycles", "depth", "max_out", "tx_count"], ascending=True).reset_index(drop=True)
    idx.to_csv(OUT_INDEX_SORTED, index=False)

    print(f"Simplest: n={idx.iloc[0]['n']}, m={idx.iloc[0]['m_unique']}, cycles={idx.iloc[0]['cycles']}, depth={idx.iloc[0]['depth']}")
    print(f"Hardest: n={idx.iloc[-1]['n']}, m={idx.iloc[-1]['m_unique']}, cycles={idx.iloc[-1]['cycles']}, depth={idx.iloc[-1]['depth']}")

    print("="*70)
    print("COMPUTING DATASET STATISTICS")
    print("="*70)

    stats_by_type = _extract_stats_by_type(OUT_INDEX_SORTED, OUT_STATS_BY_TYPE)

    global_stats = stats_by_type['_global']
    print(f"\n n (nodes): {global_stats['n']['min']}-{global_stats['n']['max']} (μ={global_stats['n']['mean']:.2f}, σ={global_stats['n']['std']:.2f})")
    print(f" m (edges): {global_stats['m_unique']['min']}-{global_stats['m_unique']['max']} (μ={global_stats['m_unique']['mean']:.2f}, σ={global_stats['m_unique']['std']:.2f})")
    print(f" depth: {global_stats['depth']['min']}-{global_stats['depth']['max']} (μ={global_stats['depth']['mean']:.2f}, σ={global_stats['depth']['std']:.2f})")
    print(f" max_out: {global_stats['max_out']['min']}-{global_stats['max_out']['max']} (μ={global_stats['max_out']['mean']:.2f}, σ={global_stats['max_out']['std']:.2f})")
    print(f" cycles: {global_stats['cycles']['min']}-{global_stats['cycles']['max']} (μ={global_stats['cycles']['mean']:.2f}, σ={global_stats['cycles']['std']:.2f})")

    # Also save global-only stats for backward compatibility
    stats_global_only = {
        'n_mean': global_stats['n']['mean'],
        'n_std': global_stats['n']['std'],
        'n_min': global_stats['n']['min'],
        'n_max': global_stats['n']['max'],
        'm_mean': global_stats['m_unique']['mean'],
        'm_std': global_stats['m_unique']['std'],
        'm_min': global_stats['m_unique']['min'],
        'm_max': global_stats['m_unique']['max'],
        'depth_mean': global_stats['depth']['mean'],
        'depth_std': global_stats['depth']['std'],
        'depth_min': global_stats['depth']['min'],
        'depth_max': global_stats['depth']['max'],
        'max_out_mean': global_stats['max_out']['mean'],
        'max_out_std': global_stats['max_out']['std'],
        'max_out_min': global_stats['max_out']['min'],
        'max_out_max': global_stats['max_out']['max'],
        'cycles_mean': global_stats['cycles']['mean'],
        'cycles_std': global_stats['cycles']['std'],
        'cycles_min': global_stats['cycles']['min'],
        'cycles_max': global_stats['cycles']['max'],
        'total_patterns': len(idx),
        'laundering_patterns': int(idx[idx['is_laundering'] == 1].shape[0]),
        'normal_patterns': int(idx[idx['is_laundering'] == 0].shape[0]),
    }

    with open(OUT_STATS, 'w') as f:
        json.dump(stats_global_only, f, indent=2)

    print(f"\nStats by laundering type saved to: {OUT_STATS_BY_TYPE}")
    print(f"Global stats saved to: {OUT_STATS}")

    print("="*70)
    print("EXTRACTION COMPLETE!")
    print("="*70)

    print(f"\nFiles created in {OUT_DIR}:")
    print(" - patterns.jsonl")
    print(" - patterns_offsets.json")
    print(" - patterns_sorted.csv")
    print(" - dataset_stats.json (global stats)")
    print(" - patterns_stats_by_type.json (per-type stats)")
    print(f"\nTotal patterns: {len(idx):,}")
    print("Ready for GCPN training!")


if __name__ == "__main__":
    build_patterns()
