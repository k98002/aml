# Issue 2 fix: stop using PPO as structural-statistic optimization

This patch changes the terminal reward from `structural_smooth` to `phase1_topology_behavior`.

Old reward:

```text
reward ~= match SAML-D means/stds for n, m_unique, cycles, depth, max_out
```

Risk:

```text
PPO learns to satisfy visible graph statistics instead of learning reusable transaction-graph construction behaviour.
```

New reward:

```text
R = 0.20 R_valid
  + 0.45 R_AML_topology_prior
  + 0.15 R_realism
  + 0.10 R_anti_degenerate
  + 0.10 R_stop_quality
```

Meaning:

- `R_valid`: graph is connected/usable and within environment limits.
- `R_AML_topology_prior`: rewards abstract topology behaviours: layering, fan-in, fan-out, circular movement, pass-through intermediary roles.
- `R_realism`: uses dataset statistics only as a broad weak plausibility regularizer.
- `R_anti_degenerate`: penalizes repeated-edge farming, over-dense graphs, and extreme hub hacks.
- `R_stop_quality`: rewards deliberate completion instead of timeout.

This does **not** claim full AML behavioural realism. It is still topology-only. It makes Phase 1 defensible as topology-level AML graph construction instead of dataset-statistic search.

Patched files:

```text
aml/environment/transaction_env.py
aml/config/train_aml.yaml
```
