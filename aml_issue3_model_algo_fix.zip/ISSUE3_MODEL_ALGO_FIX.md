# Issue 3 / Phase 1.5: Model and Algorithm Fix for Richer AML Data

This patch makes the generator consume the richer Issue 1 data pipeline instead of treating every pattern as topology-only.

## Core interface change

Old action:

```text
[node1, node2, edge_type, stop]
```

New action:

```text
[op, src, dst, amount_bin, delta_t_bin, currency_id, payment_type_id]
```

where:

```text
op = 0  ADD_TX
op = 1  STOP
```

The action remains all-discrete for Phase 1.5. Amount and time are represented by train-fitted bins produced by the data pipeline. This avoids the raw continuous-action entropy problem while still allowing the environment to reconstruct numeric amount/time values from bin centers.

## Files changed

```text
aml/environment/transaction_env.py
aml/models/policy.py
aml/algorithms/storage.py
aml/algorithms/ppo.py
aml/config/train_aml.yaml
aml/train_aml.py
aml/utils/s3_utils.py
```

## What changed

### Environment

`TransactionGraphEnv` now stores transaction events:

```python
{
    "src": int,
    "dst": int,
    "amount": float,
    "amount_bin": int,
    "delta_t": float,
    "delta_t_bin": int,
    "timestamp": float,
    "currency_id": int,
    "payment_type_id": int,
}
```

It maintains an aggregate directed graph for GCN observation and reward calculation.

### Observation

The observation now exposes:

```text
adj:  [edge_channels, max_nodes, max_nodes]
node: [1, max_nodes, 15]
```

Default edge channels:

```text
0 edge_exists
1 log_tx_count
2 log_amount_sum
3 log_amount_mean
4 recentness
5... currency/payment-type distribution channels if enabled
```

Default node features:

```text
0  in_degree
1  out_degree
2  in_tx_count
3  out_tx_count
4  log_in_amount
5  log_out_amount
6  balance_ratio
7  pass_through_ratio
8  time_span
9  recency
10 source_role
11 intermediary_role
12 sink_role
13 real_node_marker
14 new_node_marker
```

### NEW_NODE handling

The old code only allowed:

```text
existing -> NEW_NODE
```

The new code allows:

```text
existing -> existing
existing -> NEW_NODE
NEW_NODE -> existing
```

and rejects:

```text
NEW_NODE -> NEW_NODE
```

This removes the old fan-out/growing-chain bias and allows fan-in patterns.

### Policy

`GCNPolicy` is now a masked autoregressive multi-head policy:

```text
op head
src head
dst head conditioned on src
amount_bin head
_delta_t_bin head
currency head
payment_type head
value head
```

For `STOP`, only the op head contributes to log-probability. For `ADD_TX`, endpoint and attribute heads are active.

### PPO / storage

`RolloutBuffer` no longer hardcodes action shape `(4,)`. It uses `env.action_space['shape']`, which is now `(7,)`.

PPO still uses the standard clipped objective:

```text
ratio = exp(new_logprob - old_logprob)
```

Only the log-probability construction changed because the action is now multi-head.

### Entropy handling

The policy returns a per-head weighted entropy bonus:

```text
ent_op
ent_node
ent_attr
ent_amount
ent_time
```

This prevents one action family from dominating the entropy term. Continuous amount/time are intentionally deferred.

## Required Issue 1 pipeline output

The environment supports several formats, but the recommended pattern JSONL format is:

```json
{
  "pattern_id": "...",
  "is_laundering": 1,
  "laundering_type": "chain",
  "transactions": [
    {
      "src": "account_a",
      "dst": "account_b",
      "amount": 1234.56,
      "amount_bin": 7,
      "timestamp": "2023-01-01T12:00:00",
      "delta_t_bin": 2,
      "currency_id": 0,
      "payment_type_id": 1
    }
  ]
}
```

The code also accepts `edge_events`, `events`, and old `edge_index` fallback patterns.

The metadata file should be fitted on the train split only:

```json
{
  "amount_bin_num": 16,
  "delta_t_bin_num": 8,
  "currency_vocab": {"USD": 0},
  "payment_type_vocab": {"ACH": 0},
  "amount_bin_centers": [100.0, 250.0, 500.0],
  "delta_t_bin_centers": [60.0, 3600.0, 86400.0]
}
```

## What this does not do

This patch does not make amount continuous. The staged path is:

```text
Phase 1.5: amount_bin + delta_t_bin
Phase 1.6: amount_bin + continuous residual
Phase 2: adversarial detector feedback
```

This patch also does not turn the reward into full behavioural AML scoring. It keeps the Issue 2 Phase 1 topology-behaviour reward while making the MDP capable of consuming and generating richer attributed transactions.
