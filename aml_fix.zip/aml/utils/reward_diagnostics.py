"""Reward sanity checks for Phase 1.5 target/attribute reward.

Usage from repo root:
    python aml/utils/reward_diagnostics.py --config aml/config/train_aml.yaml --episodes 100

It reports:
- random valid-ish policy reward distribution
- zero-attribute random policy reward distribution
- real-pattern reward distribution by replaying train-index patterns

The script is deliberately lightweight and uses the environment reward directly.
"""
from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from environment import TransactionEnvWrapper  # noqa: E402
from environment.transaction_env import OP_ADD_TX, OP_STOP  # noqa: E402


def load_config(path: str):
    with open(path, "r") as f:
        raw = yaml.safe_load(f)
    # Resolve only the simple path defaults expected by this project.
    return SimpleNamespace(**raw)


def random_action(env: TransactionEnvWrapper, zero_attr: bool = False):
    e = env.env
    n = e.current_graph.number_of_nodes()
    can_stop = e.step_count >= e.min_action
    if can_stop and random.random() < 0.20:
        return np.array([OP_STOP, 0, 0, 0, 0, 0, 0], dtype=np.int64)
    real_nodes = list(range(max(n, 1)))
    use_new = n < e.max_nodes - 1 and random.random() < 0.35
    if use_new and random.random() < 0.5:
        src = e.new_node_idx
        dst = random.choice(real_nodes)
    elif use_new:
        src = random.choice(real_nodes)
        dst = e.new_node_idx
    else:
        src = random.choice(real_nodes)
        choices = [v for v in real_nodes if v != src]
        dst = random.choice(choices) if choices else e.new_node_idx
    if zero_attr:
        amount_bin = delta_t_bin = currency = payment = 0
    else:
        amount_bin = random.randrange(e.amount_bin_num)
        delta_t_bin = random.randrange(e.delta_t_bin_num)
        currency = random.randrange(e.currency_num)
        payment = random.randrange(e.payment_type_num)
    return np.array([OP_ADD_TX, src, dst, amount_bin, delta_t_bin, currency, payment], dtype=np.int64)


def run_random(env, episodes: int, zero_attr: bool = False):
    rewards = []
    comps = []
    for _ in range(episodes):
        obs = env.reset()
        done = False
        ep_reward = 0.0
        for _ in range(env.env.max_action + 2):
            a = random_action(env, zero_attr=zero_attr)
            obs, r, done, info = env.step(a)
            ep_reward += float(r)
            if done:
                rewards.append(ep_reward)
                comps.append(info)
                break
    return rewards, comps


def replay_real_patterns(env, limit: int):
    rewards = []
    comps = []
    n = min(limit, env.env.dataset_len)
    for idx in range(n):
        pattern = env.env.load_pattern(idx)
        events = env.env._events_from_pattern(pattern)
        target_id = env.env._target_id_from_pattern(pattern)
        env.reset()
        env.env.current_target_id = target_id
        env.env.current_target_name = env.env.target_typologies[target_id]
        raw_to_local = {}
        next_id = 0
        logical = 0.0
        for ev in events[: env.env.max_action - 1]:
            for raw in (ev["src_raw"], ev["dst_raw"]):
                if raw not in raw_to_local:
                    raw_to_local[raw] = next_id
                    next_id += 1
            if next_id >= env.env.max_nodes - 1:
                break
            logical += env.env._delta_t_from_bin(int(ev.get("delta_t_bin", 0)))
            tx = {
                "src": raw_to_local[ev["src_raw"]],
                "dst": raw_to_local[ev["dst_raw"]],
                "amount": float(ev.get("amount", env.env._amount_from_bin(int(ev.get("amount_bin", 0))))),
                "amount_bin": int(ev.get("amount_bin", 0)),
                "delta_t": float(ev.get("delta_t", env.env._delta_t_from_bin(int(ev.get("delta_t_bin", 0))))),
                "delta_t_bin": int(ev.get("delta_t_bin", 0)),
                "timestamp": logical,
                "currency_id": int(ev.get("currency_id", 0)),
                "payment_type_id": int(ev.get("payment_type_id", 0)),
            }
            env.env._append_transaction(tx)
            env.env.step_count += 1
        reward = env.env._compute_terminal_reward(terminal_reason="stop")
        info = env.env._final_info("replay", timed_out=False)
        rewards.append(float(reward))
        comps.append(info)
    return rewards, comps


def summarize(name, rewards, comps):
    if not rewards:
        print(f"{name}: no episodes")
        return
    def avg(key):
        vals = [float(c.get(key, 0.0)) for c in comps]
        return float(np.mean(vals)) if vals else 0.0
    print(f"{name}: n={len(rewards)} reward_mean={np.mean(rewards):.4f} reward_p50={np.median(rewards):.4f} reward_p90={np.percentile(rewards,90):.4f}")
    print(f"  components: valid={avg('r_valid'):.3f} target={avg('r_target_aml'):.3f} attr={avg('r_attribute_behavior'):.3f} amount={avg('r_amount_flow'):.3f} time={avg('r_time_velocity'):.3f} realism={avg('r_realism'):.3f} novelty={avg('r_novelty'):.3f}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="aml/config/train_aml.yaml")
    ap.add_argument("--episodes", type=int, default=100)
    ap.add_argument("--real-limit", type=int, default=100)
    args = ap.parse_args()
    cfg = load_config(args.config)
    env = TransactionEnvWrapper(cfg)
    r, c = run_random(env, args.episodes, zero_attr=False)
    summarize("random", r, c)
    r0, c0 = run_random(env, args.episodes, zero_attr=True)
    summarize("zero_attr_random", r0, c0)
    rr, cc = replay_real_patterns(env, args.real_limit)
    summarize("real_replay", rr, cc)


if __name__ == "__main__":
    main()
