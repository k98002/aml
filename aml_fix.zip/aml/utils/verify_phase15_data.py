"""Verify Issue-1/Phase-1.5 attributed AML data outputs.

Run from the `aml/` directory:
    python utils/verify_phase15_data.py --data-dir data
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="data")
    args = ap.parse_args()
    data = Path(args.data_dir)

    required = [
        "patterns.jsonl",
        "patterns_offsets.json",
        "patterns_train.csv",
        "patterns_val.csv",
        "patterns_test.csv",
        "patterns_metadata.json",
        "patterns_stats_train.json",
    ]
    for f in required:
        p = data / f
        if not p.exists():
            raise AssertionError(f"missing: {p}")
        print(f"OK {p} {p.stat().st_size/1024:.1f} KB")

    train = pd.read_csv(data / "patterns_train.csv")
    val = pd.read_csv(data / "patterns_val.csv")
    test = pd.read_csv(data / "patterns_test.csv")

    for name, df in [("train", train), ("val", val), ("test", test)]:
        if "pattern_id" not in df.columns:
            raise AssertionError(f"{name} missing pattern_id")
        if not df["pattern_id"].is_unique:
            raise AssertionError(f"{name} has duplicate pattern_id")

    train_ids = set(train["pattern_id"].astype(str))
    val_ids = set(val["pattern_id"].astype(str))
    test_ids = set(test["pattern_id"].astype(str))
    if not train_ids.isdisjoint(val_ids):
        raise AssertionError("train/val pattern_id leakage")
    if not train_ids.isdisjoint(test_ids):
        raise AssertionError("train/test pattern_id leakage")
    if not val_ids.isdisjoint(test_ids):
        raise AssertionError("val/test pattern_id leakage")
    print("OK split leakage check")

    offsets = json.load(open(data / "patterns_offsets.json"))
    pid = str(train.iloc[0]["pattern_id"])
    if pid not in offsets:
        raise AssertionError(f"{pid} missing from offsets")
    with open(data / "patterns.jsonl", "rb") as f:
        f.seek(int(offsets[pid]))
        rec = json.loads(f.readline())

    events = rec.get("transactions") or rec.get("edge_events") or rec.get("events")
    if not events or not isinstance(events, list):
        raise AssertionError("sample pattern has no transaction events")
    ev = events[0]
    needed = ["src", "dst", "amount_bin", "delta_t_bin", "currency_id", "payment_type_id"]
    missing = [k for k in needed if k not in ev]
    if missing:
        raise AssertionError(f"event missing keys: {missing}")

    meta = json.load(open(data / "patterns_metadata.json"))
    for k in ["amount_bin_num", "delta_t_bin_num", "amount_bin_centers", "delta_t_bin_centers", "currency_vocab", "payment_type_vocab"]:
        if k not in meta:
            raise AssertionError(f"metadata missing {k}")

    print("OK transaction attributes and metadata")
    print("train/val/test:", len(train), len(val), len(test))
    print("sample pattern:", pid)
    print("sample event:", ev)


if __name__ == "__main__":
    main()
