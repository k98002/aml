"""Reward/attribute-use diagnostics for the Phase 1.5 AML generator.

This script implements the quick checks from fix_plan1.md:
- random-policy baseline
- zero-attribute ablation
- shuffled-attribute ablation
- real-pattern reward distribution

It intentionally uses the environment reward directly. It does not train a model.
Run from the aml/ directory, for example:

    python utils/diagnose_reward_usage.py --config config/train_aml.yaml --episodes 100

The output is designed to answer one question: does the reward depend on the
richer amount/time/currency/payment attributes, or can topology alone still score
near-perfectly?
"""
from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, Iterable, List

import networkx as nx
import numpy as np
from omegaconf import OmegaConf

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from environment import TransactionEnvWrapper  # noqa: E402
from environment.transaction_env import OP_ADD_TX, OP_STOP  # noqa: E402


def load_config(path: str) -> SimpleNamespace:
    cfg = OmegaConf.load(path)
    return SimpleNamespace(**OmegaConf.to_container(cfg, resolve=True))


def mean_components(records: List[Dict[str, float]]) -> Dict[str, float]:
    keys = sorted({k for r in records for k in r.keys() if k.startswith("r_")})
    out = {}
    for k in keys:
        vals = [float(r.get(k, 0.0)) for r in records]
        out[k] = float(np.mean(vals)) if vals else 0.0
    return out


def print_block(name: str, records: List[Dict[str, float]]) -> None:
    print("\n" + "=" * 80)
    print(name)
    print("=" * 80)
    if not records:
        print("no records")
        return
    comps = mean_components(records)
    for k in [
        "r_total",
        "r_valid",
        "r_valid_gate",
        "r_target_aml",
        "r_attribute_behaviour",
        "r_amount_flow",
        "r_time_velocity",
        "r_currency_payment_realism",
        "r_bin_realism",
        "r_realism",
        "r_novelty",
        "r_stop_quality",
    ]:
        if k in comps:
            print(f"{k:32s}: {comps[k]:.4f}")


def valid_random_action(envw: TransactionEnvWrapper) -> np.ndarray:
    env = envw.env
    n = env.current_graph.number_of_nodes()
    new_idx = env.new_node_idx
    if env.step_count >= env.min_action and random.random() < 0.20:
        return np.array([OP_STOP, 0, 0, 0, 0, 0, 0], dtype=np.int64)
    real_nodes = list(range(max(n, 1)))
    use_new = n < env.max_nodes - 1 and random.random() < 0.45
    if use_new:
        if random.random() < 0.5:
            src = new_idx
            dst = random.choice(real_nodes)
        else:
            src = random.choice(real_nodes)
            dst = new_idx
    else:
        if len(real_nodes) < 2:
            src = 0
            dst = new_idx if n < env.max_nodes - 1 else 0
        else:
            src, dst = random.sample(real_nodes, 2)
    return np.array(
        [
            OP_ADD_TX,
            src,
            dst,
            random.randrange(env.amount_bin_num),
            random.randrange(env.delta_t_bin_num),
            random.randrange(env.currency_num),
            random.randrange(env.payment_type_num),
        ],
        dtype=np.int64,
    )


def random_policy_baseline(envw: TransactionEnvWrapper, episodes: int) -> List[Dict[str, float]]:
    out = []
    for _ in range(episodes):
        envw.reset()
        done = False
        info = {}
        for _ in range(envw.env.max_action):
            action = valid_random_action(envw)
            _, _, done, info = envw.step(action)
            if done:
                break
        if not done:
            _, _, _, info = envw.step(np.array([OP_STOP, 0, 0, 0, 0, 0, 0], dtype=np.int64))
        out.append({k: float(v) for k, v in info.items() if isinstance(v, (int, float, np.integer, np.floating))})
    return out


def load_patterns(envw: TransactionEnvWrapper, limit: int) -> List[Dict[str, Any]]:
    env = envw.env
    n = min(env.dataset_len, limit)
    return [env.load_pattern(i) for i in range(n)]


def build_pattern_state(envw: TransactionEnvWrapper, pattern: Dict[str, Any], mode: str = "real") -> Dict[str, float]:
    env = envw.env
    env.reset()
    events = env._events_from_pattern(pattern)
    if not events:
        return {}
    env.current_target_id = env._target_id_from_pattern(pattern, events)

    if mode == "zero_attrs":
        for ev in events:
            ev["amount_bin"] = 0
            ev["amount"] = env._amount_from_bin(0)
            ev["delta_t_bin"] = 0
            ev["delta_t"] = env._delta_t_from_bin(0)
            ev["currency_id"] = 0
            ev["payment_type_id"] = 0
    elif mode == "shuffle_attrs":
        attrs = [(ev.get("amount_bin", 0), ev.get("amount", env._amount_from_bin(0)), ev.get("delta_t_bin", 0), ev.get("delta_t", env._delta_t_from_bin(0)), ev.get("currency_id", 0), ev.get("payment_type_id", 0)) for ev in events]
        random.shuffle(attrs)
        for ev, vals in zip(events, attrs):
            ev["amount_bin"], ev["amount"], ev["delta_t_bin"], ev["delta_t"], ev["currency_id"], ev["payment_type_id"] = vals

    raw_to_local = {events[0]["src_raw"]: 0}
    local_next = 1
    env.current_graph = nx.DiGraph()
    env.current_graph.add_node(0)
    env.transactions = []
    env.logical_time = 0.0
    env.step_count = 0

    def map_raw(raw):
        nonlocal local_next
        if raw not in raw_to_local:
            raw_to_local[raw] = local_next
            local_next += 1
        return raw_to_local[raw]

    for ev in events[: env.max_action]:
        src = map_raw(ev["src_raw"])
        dst = map_raw(ev["dst_raw"])
        if src >= env.max_nodes - 1 or dst >= env.max_nodes - 1:
            continue
        env.logical_time += env._delta_t_from_bin(int(ev.get("delta_t_bin", 0)))
        tx = {
            "src": int(src),
            "dst": int(dst),
            "amount": float(ev.get("amount", env._amount_from_bin(int(ev.get("amount_bin", 0))))),
            "amount_bin": int(ev.get("amount_bin", 0)),
            "delta_t": float(ev.get("delta_t", env._delta_t_from_bin(int(ev.get("delta_t_bin", 0))))),
            "delta_t_bin": int(ev.get("delta_t_bin", 0)),
            "timestamp": float(env.logical_time),
            "currency_id": int(ev.get("currency_id", 0)),
            "payment_type_id": int(ev.get("payment_type_id", 0)),
        }
        env._append_transaction(tx)
        env.step_count += 1

    _ = env._compute_terminal_reward(terminal_reason="stop")
    info = env._final_info(reason="diagnostic", timed_out=False)
    return {k: float(v) for k, v in info.items() if isinstance(v, (int, float, np.integer, np.floating))}


def score_patterns(envw: TransactionEnvWrapper, patterns: Iterable[Dict[str, Any]], mode: str) -> List[Dict[str, float]]:
    return [build_pattern_state(envw, p, mode=mode) for p in patterns]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/train_aml.yaml")
    ap.add_argument("--episodes", type=int, default=100)
    ap.add_argument("--patterns", type=int, default=200)
    args = ap.parse_args()

    cfg = load_config(args.config)
    envw = TransactionEnvWrapper(cfg)

    random_records = random_policy_baseline(envw, args.episodes)
    print_block("random valid-action policy baseline", random_records)

    patterns = load_patterns(envw, args.patterns)
    print_block("real train patterns", score_patterns(envw, patterns, mode="real"))
    print_block("zero-attribute ablation on real patterns", score_patterns(envw, patterns, mode="zero_attrs"))
    print_block("shuffled-attribute ablation on real patterns", score_patterns(envw, patterns, mode="shuffle_attrs"))

    print("\nExpected interpretation:")
    print("- real train r_attribute_behaviour should exceed zero/shuffle ablations.")
    print("- random-policy r_total should stay clearly below trained/generated policy reward.")
    print("- if zero/shuffle scores match real scores, reward is still topology-dominant.")


if __name__ == "__main__":
    main()
