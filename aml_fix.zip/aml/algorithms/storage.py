"""Rollout buffer for attributed transaction PPO."""

from __future__ import annotations

import numpy as np
import torch


class RolloutBuffer:
    """Stores rollouts and computes GAE.

    `action_shape` is no longer hardcoded to (4,). Phase 1.5 uses the
    attributed action vector:
        [op, src, dst, amount_bin, delta_t_bin, currency_id, payment_type_id]
    """

    def __init__(self, buffer_size, obs_shape_adj, obs_shape_node, obs_shape_global=None, action_shape=(7,), device="cpu"):
        self.buffer_size = int(buffer_size)
        self.device = device
        self.action_shape = tuple(action_shape)
        self.obs_shape_global = tuple(obs_shape_global or (0,))

        self.obs_adj = torch.zeros((buffer_size, *obs_shape_adj), dtype=torch.float32)
        self.obs_node = torch.zeros((buffer_size, *obs_shape_node), dtype=torch.float32)
        self.obs_global = torch.zeros((buffer_size, *self.obs_shape_global), dtype=torch.float32)
        self.actions = torch.zeros((buffer_size, *self.action_shape), dtype=torch.long)
        self.rewards = torch.zeros(buffer_size, dtype=torch.float32)
        self.values = torch.zeros(buffer_size, dtype=torch.float32)
        self.log_probs = torch.zeros(buffer_size, dtype=torch.float32)
        self.dones = torch.zeros(buffer_size, dtype=torch.bool)
        self.advantages = torch.zeros(buffer_size, dtype=torch.float32)
        self.returns = torch.zeros(buffer_size, dtype=torch.float32)
        self.reset()

    def reset(self):
        self.ptr = 0
        self.full = False

    def add(self, obs_adj, obs_node, obs_global, action, reward, value, log_prob, done):
        if self.ptr >= self.buffer_size:
            raise RuntimeError("RolloutBuffer overflow")
        self.obs_adj[self.ptr] = torch.as_tensor(obs_adj, dtype=torch.float32)
        self.obs_node[self.ptr] = torch.as_tensor(obs_node, dtype=torch.float32)
        self.obs_global[self.ptr] = torch.as_tensor(obs_global, dtype=torch.float32).reshape(self.obs_shape_global)
        self.actions[self.ptr] = torch.as_tensor(action, dtype=torch.long).reshape(self.action_shape)
        self.rewards[self.ptr] = torch.as_tensor(reward, dtype=torch.float32)
        self.values[self.ptr] = torch.as_tensor(value, dtype=torch.float32)
        self.log_probs[self.ptr] = torch.as_tensor(log_prob, dtype=torch.float32)
        self.dones[self.ptr] = torch.as_tensor(done, dtype=torch.bool)
        self.ptr += 1
        if self.ptr == self.buffer_size:
            self.full = True

    def compute_advantages(self, last_value, gamma=0.99, lam=0.95):
        last_gae_lam = 0.0
        for step in reversed(range(self.ptr)):
            if step == self.ptr - 1:
                next_non_terminal = 1.0 - self.dones[step].float()
                next_value = torch.as_tensor(last_value, dtype=torch.float32)
            else:
                next_non_terminal = 1.0 - self.dones[step].float()
                next_value = self.values[step + 1]
            delta = self.rewards[step] + gamma * next_value * next_non_terminal - self.values[step]
            last_gae_lam = delta + gamma * lam * next_non_terminal * last_gae_lam
            self.advantages[step] = last_gae_lam
        self.returns[: self.ptr] = self.advantages[: self.ptr] + self.values[: self.ptr]

    def get_batch_iterator(self, batch_size):
        # Normalize once before batching. Avoid NaNs for tiny buffers.
        adv = self.advantages[: self.ptr]
        adv_mean = adv.mean()
        adv_std = adv.std(unbiased=False)
        self.advantages[: self.ptr] = (adv - adv_mean) / (adv_std + 1e-8)

        indices = np.random.permutation(self.ptr)
        start_idx = 0
        while start_idx < self.ptr:
            batch_indices = indices[start_idx : start_idx + batch_size]
            yield {
                "obs_adj": self.obs_adj[batch_indices].to(self.device),
                "obs_node": self.obs_node[batch_indices].to(self.device),
                "obs_global": self.obs_global[batch_indices].to(self.device),
                "actions": self.actions[batch_indices].to(self.device),
                "advantages": self.advantages[batch_indices].to(self.device),
                "returns": self.returns[batch_indices].to(self.device),
                "old_log_probs": self.log_probs[batch_indices].to(self.device),
            }
            start_idx += batch_size
