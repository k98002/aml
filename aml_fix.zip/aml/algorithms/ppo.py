"""
Proximal Policy Optimization (PPO) algorithm for PyTorch GCPN
"""
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from collections import deque

from .storage import RolloutBuffer


class PPO:
    """
    PPO algorithm implementation for GCPN.

    Args:
        policy: Policy network
        config: Configuration object
        device: Device to run on
    """

    def __init__(self, policy, config, device='cpu'):
        self.policy = policy
        self.config = config
        self.device = device

        # Optimizer
        self.optimizer = optim.Adam(policy.parameters(), lr=config.lr)

        # Statistics tracking
        self.total_steps = 0
        self.total_episodes = 0

    def collect_rollouts(self, env, n_steps):
        """
        Collect rollouts from the environment.

        Args:
            env: Environment instance
            n_steps: Number of steps to collect

        Returns:
            buffer: RolloutBuffer with collected data
            ep_info: List of episode information dictionaries
        """
        # Create buffer
        obs_shape_adj = env.observation_space['adj'].shape
        obs_shape_node = env.observation_space['node'].shape
        obs_shape_global = env.observation_space.get('global', np.zeros((0,), dtype=np.float32)).shape
        buffer = RolloutBuffer(n_steps, obs_shape_adj, obs_shape_node, obs_shape_global=obs_shape_global, action_shape=env.action_space['shape'], device=self.device)

        # Episode statistics
        ep_info = []
        ep_rewards = deque(maxlen=100)
        ep_lengths = deque(maxlen=100)
        ep_lengths_valid = deque(maxlen=100)
        action_hist = {
            'op_histogram': np.zeros(2, dtype=np.int64),
            'amount_bin_histogram': np.zeros(int(env.action_space['n'][3]), dtype=np.int64),
            'delta_t_bin_histogram': np.zeros(int(env.action_space['n'][4]), dtype=np.int64),
            'currency_histogram': np.zeros(int(env.action_space['n'][5]), dtype=np.int64),
            'payment_type_histogram': np.zeros(int(env.action_space['n'][6]), dtype=np.int64),
        }
        entropy_sums = {
            'entropy_op': 0.0,
            'entropy_src': 0.0,
            'entropy_dst': 0.0,
            'entropy_amount_bin': 0.0,
            'entropy_delta_t_bin': 0.0,
            'entropy_currency': 0.0,
            'entropy_payment_type': 0.0,
        }
        entropy_count = 0

        # Current episode tracking
        current_ep_reward = 0
        current_ep_reward_env = 0
        current_ep_length = 0
        current_ep_length_valid = 0

        # Reset environment
        obs = env.reset()
        obs_adj = obs['adj'][None, ...]  # Add batch dimension
        obs_node = obs['node'][None, ...]
        obs_global = obs.get('global', np.zeros(obs_shape_global, dtype=np.float32))[None, ...]

        self.policy.eval()
        with torch.no_grad():
            for step in range(n_steps):
                # Convert observations to tensors
                obs_adj_tensor = torch.from_numpy(obs_adj).float().to(self.device)
                obs_node_tensor = torch.from_numpy(obs_node).float().to(self.device)
                obs_global_tensor = torch.from_numpy(obs_global).float().to(self.device)

                # Get action from policy
                actions, log_probs, values, _, _, log_prob_dict = self.policy(obs_adj_tensor, obs_node_tensor, obs_global=obs_global_tensor)

                # Convert to numpy for environment
                action = actions[0].cpu().numpy()
                value = values[0].item()
                log_prob = log_probs[0].item()
                action_hist['op_histogram'][int(action[0])] += 1
                action_hist['amount_bin_histogram'][int(action[3])] += 1
                action_hist['delta_t_bin_histogram'][int(action[4])] += 1
                action_hist['currency_histogram'][int(action[5])] += 1
                action_hist['payment_type_histogram'][int(action[6])] += 1
                for k in entropy_sums:
                    if k in log_prob_dict:
                        entropy_sums[k] += float(log_prob_dict[k][0].detach().cpu().item())
                entropy_count += 1

                # Take step in environment
                obs_next, reward, done, info = env.step(action[None, ...])

                # Store in buffer
                buffer.add(
                    obs_adj[0],  # Remove batch dimension
                    obs_node[0],
                    obs_global[0],
                    action,
                    reward,
                    value,
                    log_prob,
                    done
                )

                # Update episode statistics
                current_ep_reward += reward
                current_ep_length += 1

                # Track valid actions (actions with positive reward)
                if reward > 0:
                    current_ep_length_valid += 1
                    current_ep_reward_env += reward

                # Update observation
                obs_adj = obs_next['adj'][None, ...]
                obs_node = obs_next['node'][None, ...]
                obs_global = obs_next.get('global', np.zeros(obs_shape_global, dtype=np.float32))[None, ...]

                self.total_steps += 1

                # Handle episode end
                if done:
                    # Record episode info
                    ep_info.append({
                        'reward': current_ep_reward,
                        'reward_env': current_ep_reward_env,
                        'length': current_ep_length,
                        'length_valid': current_ep_length_valid,
                        'info': info
                    })

                    ep_rewards.append(current_ep_reward)
                    ep_lengths.append(current_ep_length)
                    ep_lengths_valid.append(current_ep_length_valid)

                    # Reset episode tracking
                    current_ep_reward = 0
                    current_ep_reward_env = 0
                    current_ep_length = 0
                    current_ep_length_valid = 0
                    self.total_episodes += 1

                    # Reset environment
                    obs = env.reset()
                    obs_adj = obs['adj'][None, ...]
                    obs_node = obs['node'][None, ...]
                    obs_global = obs.get('global', np.zeros(obs_shape_global, dtype=np.float32))[None, ...]

            # Bootstrap value for last state (if not done)
            if not done:
                obs_adj_tensor = torch.from_numpy(obs_adj).float().to(self.device)
                obs_node_tensor = torch.from_numpy(obs_node).float().to(self.device)
                obs_global_tensor = torch.from_numpy(obs_global).float().to(self.device)
                _, _, last_value, _, _, _ = self.policy(obs_adj_tensor, obs_node_tensor, obs_global=obs_global_tensor)
                last_value = last_value[0].item()
            else:
                last_value = 0.0

        # Compute advantages
        buffer.compute_advantages(last_value, gamma=self.config.gamma, lam=self.config.lam)

        rollout_stats = {k: (v / max(entropy_count, 1)) for k, v in entropy_sums.items()}
        rollout_stats.update({k: v.tolist() for k, v in action_hist.items()})
        return buffer, ep_info, rollout_stats

    def update(self, buffer):
        """
        Update policy using PPO.

        Args:
            buffer: RolloutBuffer with collected data

        Returns:
            Dictionary with training statistics
        """
        self.policy.train()

        stats = {
            'policy_loss': [],
            'value_loss': [],
            'entropy': [],
            'approx_kl': [],
            'clip_fraction': [],
        }

        # Multiple epochs over the data
        for epoch in range(self.config.optim_epochs):
            # Iterate over batches
            for batch in buffer.get_batch_iterator(self.config.optim_batchsize):
                # Evaluate actions with current policy
                log_probs, values, entropy = self.policy.evaluate_actions(
                    batch['obs_adj'],
                    batch['obs_node'],
                    batch['obs_global'],
                    batch['actions']
                )

                # Flatten values
                values = values.squeeze(-1)

                # Compute policy loss (PPO clip objective)
                ratio = torch.exp(log_probs - batch['old_log_probs'])
                surr1 = ratio * batch['advantages']
                surr2 = torch.clamp(ratio, 1.0 - self.config.clip_param, 1.0 + self.config.clip_param) * batch['advantages']
                policy_loss = -torch.min(surr1, surr2).mean()

                # Compute value loss
                value_loss = nn.functional.mse_loss(values, batch['returns'])

                # Entropy is already a per-head weighted bonus returned by the policy.
                entropy_bonus = entropy.mean()

                # Total loss
                value_coef = getattr(self.config, 'value_coef', 0.5)
                loss = policy_loss + value_coef * value_loss - entropy_bonus

                # Optimize
                self.optimizer.zero_grad()
                loss.backward()
                # Gradient clipping
                torch.nn.utils.clip_grad_norm_(self.policy.parameters(), 0.5)
                self.optimizer.step()

                # Logging
                with torch.no_grad():
                    approx_kl = (batch['old_log_probs'] - log_probs).mean().item()
                    clip_fraction = ((ratio - 1.0).abs() > self.config.clip_param).float().mean().item()

                stats['policy_loss'].append(policy_loss.item())
                stats['value_loss'].append(value_loss.item())
                stats['entropy'].append(entropy_bonus.item())
                stats['approx_kl'].append(approx_kl)
                stats['clip_fraction'].append(clip_fraction)

        # Average statistics
        for key in stats:
            stats[key] = np.mean(stats[key])

        return stats

    def train_expert(self, env, batch_size, curriculum=0, level=0, level_total=6):
        """
        Expert imitation

        Args:
            env: Environment instance
            batch_size: Batch size for expert data
            curriculum: Whether to use curriculum learning
            level: Current curriculum level
            level_total: Total curriculum levels

        Returns:
            Dictionary with training statistics
        """
        self.policy.train()

        # Get expert data from environment
        expert_obs, expert_actions = env.get_expert(
            batch_size,
            curriculum=curriculum,
            level=level,
            level_total=level_total
        )

        # Convert to tensors
        obs_adj = torch.from_numpy(expert_obs['adj']).float().to(self.device)
        obs_node = torch.from_numpy(expert_obs['node']).float().to(self.device)
        obs_global = torch.from_numpy(expert_obs.get('global', np.zeros((obs_adj.shape[0], 0), dtype=np.float32))).float().to(self.device)
        actions = torch.from_numpy(expert_actions).long().to(self.device)

        # Forward pass. log_probs already applies the action mask:
        # STOP trains only the op head; ADD_TX trains op + endpoint + attribute heads.
        _, log_probs, _, _, logits_dict, log_prob_dict = self.policy(obs_adj, obs_node, obs_global=obs_global, ac_real=actions)

        # Action layout: [op, src, dst, amount_bin, delta_t_bin, currency, payment_type]
        stop_mask = (actions[:, 0] == 1)
        add_mask = (actions[:, 0] == 0)

        stop_loss = -log_prob_dict['op'][stop_mask].mean() if stop_mask.sum() > 0 else None
        add_terms = None
        if add_mask.sum() > 0:
            add_terms = (
                log_prob_dict['op'][add_mask] +
                log_prob_dict['src'][add_mask] +
                log_prob_dict['dst'][add_mask] +
                log_prob_dict['amount'][add_mask] +
                log_prob_dict['delta_t'][add_mask] +
                log_prob_dict['currency'][add_mask] +
                log_prob_dict['payment_type'][add_mask]
            )
            add_loss = -add_terms.mean()
        else:
            add_loss = None

        if bool(getattr(self.config, 'expert_balance_stop_loss', True)) and stop_loss is not None and add_loss is not None:
            loss = 0.5 * stop_loss + 0.5 * add_loss
        else:
            loss = -log_probs.mean()

        with torch.no_grad():
            op_pred = logits_dict['logits_op'].argmax(dim=1)
            stop_acc = (op_pred[stop_mask] == actions[stop_mask, 0]).float().mean().item() if stop_mask.sum() > 0 else 0.0
            add_acc = (op_pred[add_mask] == actions[add_mask, 0]).float().mean().item() if add_mask.sum() > 0 else 0.0
            src_acc = logits_dict['logits_src'].argmax(dim=1)[add_mask].eq(actions[add_mask, 1]).float().mean().item() if add_mask.sum() > 0 else 0.0
            dst_acc = logits_dict['logits_dst'].argmax(dim=1)[add_mask].eq(actions[add_mask, 2]).float().mean().item() if add_mask.sum() > 0 else 0.0
            amount_acc = logits_dict['logits_amount'].argmax(dim=1)[add_mask].eq(actions[add_mask, 3]).float().mean().item() if add_mask.sum() > 0 else 0.0
            time_acc = logits_dict['logits_delta_t'].argmax(dim=1)[add_mask].eq(actions[add_mask, 4]).float().mean().item() if add_mask.sum() > 0 else 0.0

        stats = {
            'expert_loss': loss.item(),
            'num_stop': stop_mask.sum().item(),
            'num_node': add_mask.sum().item(),
            'loss_stop': float(stop_loss.item()) if stop_loss is not None else 0.0,
            'loss_nodes': float(add_loss.item()) if add_loss is not None else 0.0,
            'acc_stop': stop_acc,
            'acc_add_op': add_acc,
            'acc_src': src_acc,
            'acc_dst': dst_acc,
            'acc_amount': amount_acc,
            'acc_time': time_acc,
        }

        # Optimize
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy.parameters(), 0.5)
        self.optimizer.step()

        return stats

    def save(self, path):
        """Save model checkpoint"""
        torch.save({
            'policy_state_dict': self.policy.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'total_steps': self.total_steps,
            'total_episodes': self.total_episodes,
        }, path)

    def load(self, path):
        """Load model checkpoint"""
        checkpoint = torch.load(path, map_location=self.device)
        self.policy.load_state_dict(checkpoint['policy_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.total_steps = checkpoint['total_steps']
        self.total_episodes = checkpoint['total_episodes']
