"""
Attributed GCN policy for AML transaction graph generation.

Action schema:
    [op, src, dst, amount_bin, delta_t_bin, currency_id, payment_type_id]

All heads are categorical for Phase 1.5. This avoids raw continuous amount/time
entropy issues while still allowing numeric values through train-fitted bins.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical

from .gcn import GCNStack


ACTION_OP = 0
ACTION_SRC = 1
ACTION_DST = 2
ACTION_AMOUNT_BIN = 3
ACTION_DELTA_T_BIN = 4
ACTION_CURRENCY = 5
ACTION_PAYMENT_TYPE = 6
ACTION_DIM = 7
OP_ADD_TX = 0
OP_STOP = 1


class GCNPolicy(nn.Module):
    """Masked autoregressive attributed transaction-action policy."""

    def __init__(self, observation_space, action_space, atom_type_num, config):
        super().__init__()
        self.observation_space = observation_space
        self.action_space = action_space
        self.atom_type_num = atom_type_num
        self.config = config

        self.node_feature_dim = observation_space["node"].shape[2]
        self.edge_dim = observation_space["adj"].shape[0]
        self.max_nodes = observation_space["adj"].shape[1]
        self.global_dim = int(observation_space.get("global", torch.zeros(0)).shape[0])
        self.emb_size = int(config.emb_size)
        self.node_embed_dim = int(getattr(config, "node_embed_dim", 16))

        nvec = list(action_space.get("n", [2, self.max_nodes, self.max_nodes, 16, 8, 1, 1]))
        if len(nvec) != ACTION_DIM:
            raise ValueError(f"Attributed policy expects {ACTION_DIM} action heads, got n={nvec}")
        self.op_num, self.src_num, self.dst_num, self.amount_bin_num, self.delta_t_bin_num, self.currency_num, self.payment_type_num = [int(x) for x in nvec]

        self.node_embedding = nn.Linear(self.node_feature_dim, self.node_embed_dim, bias=False)
        self.gcn_stack = GCNStack(
            num_layers=config.layer_num_g,
            in_channels=self.node_embed_dim,
            hidden_channels=self.emb_size,
            edge_dim=self.edge_dim,
            aggregate=config.gcn_aggregate,
            has_residual=config.has_residual,
            has_concat=config.has_concat,
            bn=config.bn,
        )
        self.global_proj = nn.Linear(self.global_dim, self.emb_size) if self.global_dim > 0 else None

        # Node scoring with graph context.
        self.node_score_mlp1 = nn.Linear(self.emb_size * 2, self.emb_size)
        self.src_score_mlp2 = nn.Linear(self.emb_size, 1)
        self.dst_score_mlp2 = nn.Linear(self.emb_size, 1)

        # Graph-level and pair-level heads.
        self.op_mlp1 = nn.Linear(self.emb_size, self.emb_size)
        self.op_mlp2 = nn.Linear(self.emb_size, self.op_num)

        pair_in_dim = self.emb_size * 3  # graph + src + dst
        self.attr_mlp = nn.Linear(pair_in_dim, self.emb_size)
        self.amount_head = nn.Linear(self.emb_size, self.amount_bin_num)
        self.delta_t_head = nn.Linear(self.emb_size, self.delta_t_bin_num)
        self.currency_head = nn.Linear(self.emb_size, self.currency_num)
        self.payment_type_head = nn.Linear(self.emb_size, self.payment_type_num)

        self.value_mlp1 = nn.Linear(self.emb_size, self.emb_size)
        self.value_mlp2 = nn.Linear(self.emb_size, 1)

        if config.bn:
            self.node_emb_bn = nn.BatchNorm1d(self.node_embed_dim)
            self.value_bn = nn.BatchNorm1d(self.emb_size)
        else:
            self.node_emb_bn = None
            self.value_bn = None

        # Per-head entropy coefficients. PPO consumes the already weighted entropy
        # bonus. This prevents continuous/categorical entropy mixing issues later.
        self.ent_op = float(getattr(config, "ent_op", getattr(config, "entcoeff", 0.01)))
        self.ent_node = float(getattr(config, "ent_node", getattr(config, "entcoeff", 0.01)))
        self.ent_attr = float(getattr(config, "ent_attr", getattr(config, "entcoeff", 0.005)))
        self.ent_amount = float(getattr(config, "ent_amount", getattr(config, "entcoeff", 0.005)))
        self.ent_time = float(getattr(config, "ent_time", getattr(config, "entcoeff", 0.005)))

    # ------------------------------------------------------------------
    # Encoders and masks
    # ------------------------------------------------------------------
    def _encode(self, obs_adj: torch.Tensor, obs_node: torch.Tensor, obs_global: Optional[torch.Tensor] = None):
        batch_size = obs_adj.shape[0]
        obs_node_squeezed = obs_node.squeeze(1)
        node_emb_input = self.node_embedding(obs_node_squeezed)
        if self.config.bn and self.node_emb_bn is not None:
            node_emb_input = node_emb_input.reshape(-1, self.node_embed_dim)
            node_emb_input = self.node_emb_bn(node_emb_input)
            node_emb_input = node_emb_input.reshape(batch_size, self.max_nodes, self.node_embed_dim)
        node_emb_input = node_emb_input.unsqueeze(1)
        emb_node = self.gcn_stack(obs_adj, node_emb_input)

        real_mask, new_mask, valid_mask = self._node_masks(obs_node)
        if getattr(self.config, "mask_null", False):
            emb_node = emb_node * valid_mask.unsqueeze(-1).float()
        emb_graph = self._masked_graph_pool(emb_node, valid_mask)
        if self.global_proj is not None:
            if obs_global is None:
                obs_global = torch.zeros((batch_size, self.global_dim), dtype=emb_graph.dtype, device=emb_graph.device)
            emb_graph = emb_graph + torch.tanh(self.global_proj(obs_global.float()))
        return emb_node, emb_graph, real_mask, new_mask, valid_mask

    def _node_masks(self, obs_node: torch.Tensor):
        x = obs_node.squeeze(1)
        batch_size = x.shape[0]
        device = x.device
        if self.node_feature_dim >= 15:
            real_mask = x[..., 13] > 0.5
            new_mask = x[..., 14] > 0.5
        else:
            # Backward fallback: any nonzero feature is valid; last index is NEW_NODE.
            valid = x.abs().sum(dim=-1) > 0
            real_mask = valid.clone()
            real_mask[:, -1] = False
            new_mask = torch.zeros_like(real_mask)
            new_mask[:, -1] = True
        # Force the reserved token to be the final node index even if metadata is odd.
        idx = torch.arange(self.max_nodes, device=device).unsqueeze(0).expand(batch_size, -1)
        new_token = idx == (self.max_nodes - 1)
        new_mask = new_mask | new_token
        real_mask = real_mask & (~new_token)
        valid_mask = real_mask | new_mask
        return real_mask, new_mask, valid_mask

    @staticmethod
    def _masked_graph_pool(emb_node: torch.Tensor, valid_mask: torch.Tensor):
        weights = valid_mask.float().unsqueeze(-1)
        denom = weights.sum(dim=1).clamp_min(1.0)
        return (emb_node * weights).sum(dim=1) / denom

    def _node_logits(self, emb_node: torch.Tensor, emb_graph: torch.Tensor, head: str):
        graph_expand = emb_graph.unsqueeze(1).expand(-1, self.max_nodes, -1)
        h = F.relu(self.node_score_mlp1(torch.cat([emb_node, graph_expand], dim=-1)))
        if head == "src":
            return self.src_score_mlp2(h).squeeze(-1)
        return self.dst_score_mlp2(h).squeeze(-1)

    @staticmethod
    def _safe_categorical(logits: torch.Tensor) -> Categorical:
        # If a row is fully masked, Categorical(-inf) would produce NaNs. The
        # environment should prevent this, but this guard keeps training robust.
        all_bad = torch.isinf(logits).all(dim=-1)
        if all_bad.any():
            logits = logits.clone()
            logits[all_bad] = 0.0
        return Categorical(logits=logits)

    def _mask_logits(self, logits: torch.Tensor, mask: torch.Tensor):
        return logits.masked_fill(~mask, -1e10)

    def _new_allowed_mask(self, real_mask: torch.Tensor, new_mask: torch.Tensor):
        graph_full = real_mask.sum(dim=1) >= (self.max_nodes - 1)
        return new_mask & (~graph_full.unsqueeze(1))

    def _src_mask(self, real_mask: torch.Tensor, new_mask: torch.Tensor):
        # Allow NEW_NODE as source to support fan-in / aggregation patterns,
        # unless the graph has already reached max real nodes.
        return real_mask | self._new_allowed_mask(real_mask, new_mask)

    def _dst_mask(self, real_mask: torch.Tensor, new_mask: torch.Tensor, src: torch.Tensor):
        batch_size = src.shape[0]
        device = src.device
        mask = real_mask | self._new_allowed_mask(real_mask, new_mask)
        src_is_new = src == (self.max_nodes - 1)
        # If src is NEW, dst must be an existing real node; disallow NEW->NEW.
        mask[src_is_new] = real_mask[src_is_new]
        # If src is existing, disallow self-loop; NEW destination remains allowed.
        row = torch.arange(batch_size, device=device)
        existing_src = ~src_is_new
        mask[row[existing_src], src[existing_src]] = False
        return mask

    def _endpoint_embeddings(self, emb_node: torch.Tensor, src: torch.Tensor, dst: torch.Tensor):
        batch_idx = torch.arange(emb_node.shape[0], device=emb_node.device)
        emb_src = emb_node[batch_idx, src]
        emb_dst = emb_node[batch_idx, dst]
        return emb_src, emb_dst

    # ------------------------------------------------------------------
    # Policy API
    # ------------------------------------------------------------------
    def forward(self, obs_adj, obs_node, obs_global=None, deterministic: bool = False, ac_real: Optional[torch.Tensor] = None):
        batch_size = obs_adj.shape[0]
        device = obs_adj.device
        emb_node, emb_graph, real_mask, new_mask, valid_mask = self._encode(obs_adj, obs_node, obs_global)

        # Value.
        value_h = F.relu(self.value_mlp1(emb_graph))
        value = self.value_mlp2(value_h)

        # op: ADD_TX or STOP.
        logits_op = self.op_mlp2(F.relu(self.op_mlp1(emb_graph)))
        dist_op = Categorical(logits=logits_op)
        if ac_real is not None:
            ac_op = ac_real[:, ACTION_OP].long()
        else:
            ac_op = logits_op.argmax(dim=1) if deterministic else dist_op.sample()

        # src.
        logits_src = self._node_logits(emb_node, emb_graph, head="src")
        logits_src = self._mask_logits(logits_src, self._src_mask(real_mask, new_mask))
        dist_src = self._safe_categorical(logits_src)
        if ac_real is not None:
            ac_src = ac_real[:, ACTION_SRC].long()
        else:
            ac_src = logits_src.argmax(dim=1) if deterministic else dist_src.sample()

        # dst conditioned on src.
        logits_dst = self._node_logits(emb_node, emb_graph, head="dst")
        logits_dst = self._mask_logits(logits_dst, self._dst_mask(real_mask, new_mask, ac_src))
        dist_dst = self._safe_categorical(logits_dst)
        if ac_real is not None:
            ac_dst = ac_real[:, ACTION_DST].long()
        else:
            ac_dst = logits_dst.argmax(dim=1) if deterministic else dist_dst.sample()

        # Attribute heads conditioned on graph + endpoints.
        emb_src, emb_dst = self._endpoint_embeddings(emb_node, ac_src.clamp(0, self.max_nodes - 1), ac_dst.clamp(0, self.max_nodes - 1))
        attr_h = F.relu(self.attr_mlp(torch.cat([emb_graph, emb_src, emb_dst], dim=-1)))
        logits_amount = self.amount_head(attr_h)
        logits_delta_t = self.delta_t_head(attr_h)
        logits_currency = self.currency_head(attr_h)
        logits_payment = self.payment_type_head(attr_h)

        dist_amount = Categorical(logits=logits_amount)
        dist_delta_t = Categorical(logits=logits_delta_t)
        dist_currency = Categorical(logits=logits_currency)
        dist_payment = Categorical(logits=logits_payment)

        if ac_real is not None:
            ac_amount = ac_real[:, ACTION_AMOUNT_BIN].long()
            ac_delta_t = ac_real[:, ACTION_DELTA_T_BIN].long()
            ac_currency = ac_real[:, ACTION_CURRENCY].long()
            ac_payment = ac_real[:, ACTION_PAYMENT_TYPE].long()
        else:
            ac_amount = logits_amount.argmax(dim=1) if deterministic else dist_amount.sample()
            ac_delta_t = logits_delta_t.argmax(dim=1) if deterministic else dist_delta_t.sample()
            ac_currency = logits_currency.argmax(dim=1) if deterministic else dist_currency.sample()
            ac_payment = logits_payment.argmax(dim=1) if deterministic else dist_payment.sample()

        actions = torch.stack([ac_op, ac_src, ac_dst, ac_amount, ac_delta_t, ac_currency, ac_payment], dim=1)

        logp_op = dist_op.log_prob(actions[:, ACTION_OP])
        logp_src = dist_src.log_prob(actions[:, ACTION_SRC])
        logp_dst = dist_dst.log_prob(actions[:, ACTION_DST])
        logp_amount = dist_amount.log_prob(actions[:, ACTION_AMOUNT_BIN])
        logp_delta_t = dist_delta_t.log_prob(actions[:, ACTION_DELTA_T_BIN])
        logp_currency = dist_currency.log_prob(actions[:, ACTION_CURRENCY])
        logp_payment = dist_payment.log_prob(actions[:, ACTION_PAYMENT_TYPE])

        add_mask = (actions[:, ACTION_OP] == OP_ADD_TX).float()
        log_probs = logp_op + add_mask * (
            logp_src + logp_dst + logp_amount + logp_delta_t + logp_currency + logp_payment
        )

        ent_op = dist_op.entropy()
        ent_src = dist_src.entropy()
        ent_dst = dist_dst.entropy()
        ent_amount = dist_amount.entropy()
        ent_delta_t = dist_delta_t.entropy()
        ent_currency = dist_currency.entropy()
        ent_payment = dist_payment.entropy()
        entropy_bonus = self.ent_op * ent_op + add_mask * (
            self.ent_node * (ent_src + ent_dst)
            + self.ent_amount * ent_amount
            + self.ent_time * ent_delta_t
            + self.ent_attr * (ent_currency + ent_payment)
        )

        logits_dict = {
            "logits_op": logits_op,
            "logits_src": logits_src,
            "logits_dst": logits_dst,
            "logits_amount": logits_amount,
            "logits_delta_t": logits_delta_t,
            "logits_currency": logits_currency,
            "logits_payment": logits_payment,
        }
        log_prob_dict = {
            "op": logp_op,
            "src": logp_src,
            "dst": logp_dst,
            "amount": logp_amount,
            "delta_t": logp_delta_t,
            "currency": logp_currency,
            "payment_type": logp_payment,
            "add_mask": add_mask,
            "entropy_raw_mean": (ent_op + ent_src + ent_dst + ent_amount + ent_delta_t + ent_currency + ent_payment) / 7.0,
            "entropy_op": ent_op,
            "entropy_src": ent_src,
            "entropy_dst": ent_dst,
            "entropy_amount_bin": ent_amount,
            "entropy_delta_t_bin": ent_delta_t,
            "entropy_currency": ent_currency,
            "entropy_payment_type": ent_payment,
        }
        return actions, log_probs, value, entropy_bonus, logits_dict, log_prob_dict

    def evaluate_actions(self, obs_adj, obs_node, obs_global, actions):
        _, log_probs, value, entropy_bonus, _, _ = self.forward(obs_adj, obs_node, obs_global=obs_global, ac_real=actions)
        return log_probs, value, entropy_bonus
